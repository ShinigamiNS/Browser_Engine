// quickjs_adapter.cpp
// Bridges QuickJS (full ES2020) to our Node DOM tree.
// Replaces the toy js.cpp engine entirely.

#include "quickjs_adapter.h"
#include "dom.h"

extern "C" {
#include "quickjs.h"
}

#include <string>
#include <memory>
#include <functional>
#include <iostream>
#include <sstream>
#include <algorithm>

// ── Engine state ───────────────────────────────────────────────────────────
struct QJSEngine {
    JSRuntime *rt  = nullptr;
    JSContext *ctx = nullptr;
    std::shared_ptr<Node> dom_root;
    bool dom_dirty = false;
};

// ── JS value helpers ───────────────────────────────────────────────────────
static std::string js_to_string(JSContext *ctx, JSValue val) {
    size_t len;
    const char *str = JS_ToCStringLen(ctx, &len, val);
    if (!str) return "";
    std::string s(str, len);
    JS_FreeCString(ctx, str);
    return s;
}

static JSValue js_from_string(JSContext *ctx, const std::string& s) {
    return JS_NewStringLen(ctx, s.c_str(), s.size());
}

// ── Node → JSValue wrapping ────────────────────────────────────────────────
// We store a raw Node* as opaque pointer in a JS object.
// The Node is kept alive by the shared_ptr in the DOM tree.

static JSClassID node_class_id = 0;

static void node_finalizer(JSRuntime *rt, JSValue val) {
    // Node is owned by the DOM tree; we don't delete it here
}

static JSClassDef node_class_def = {
    "Node",
    .finalizer = node_finalizer,
};

static Node* get_node(JSContext *ctx, JSValue obj) {
    return static_cast<Node*>(JS_GetOpaque(obj, node_class_id));
}

static JSValue wrap_node(JSContext *ctx, std::shared_ptr<Node> node,
                         QJSEngine *engine);

// ── DOM method implementations ─────────────────────────────────────────────

static JSValue js_get_style(JSContext *ctx, JSValue this_val,
                             int argc, JSValue *argv) {
    Node *node = get_node(ctx, this_val);
    if (!node) return JS_UNDEFINED;
    // Return a style proxy object
    JSValue style = JS_NewObject(ctx);
    // setProperty helper used by setAttribute("style", ...)
    // For now store as inline style string
    JS_SetPropertyStr(ctx, style, "_node_ptr",
        JS_NewInt64(ctx, (int64_t)(uintptr_t)node));
    return style;
}

// node.style.setProperty / direct assignment handled via Proxy
// Simplified: set individual style properties via setAttribute
static JSValue js_style_set(JSContext *ctx, JSValue this_val,
                             int argc, JSValue *argv) {
    if (argc < 2) return JS_UNDEFINED;
    // Get node from parent
    JSValue node_ptr_val = JS_GetPropertyStr(ctx, this_val, "_node_ptr");
    int64_t ptr_int = 0;
    JS_ToInt64(ctx, &ptr_int, node_ptr_val);
    JS_FreeValue(ctx, node_ptr_val);
    Node *node = reinterpret_cast<Node*>((uintptr_t)ptr_int);
    if (!node) return JS_UNDEFINED;

    std::string prop = js_to_string(ctx, argv[0]);
    std::string val  = js_to_string(ctx, argv[1]);
    std::string& cur = node->attributes["style"];
    cur += prop + ":" + val + ";";
    return JS_UNDEFINED;
}

static JSValue js_set_attribute(JSContext *ctx, JSValue this_val,
                                 int argc, JSValue *argv) {
    if (argc < 2) return JS_UNDEFINED;
    Node *node = get_node(ctx, this_val);
    if (!node) return JS_UNDEFINED;
    std::string name = js_to_string(ctx, argv[0]);
    std::string val  = js_to_string(ctx, argv[1]);
    std::transform(name.begin(), name.end(), name.begin(), ::tolower);
    node->attributes[name] = val;
    return JS_UNDEFINED;
}

static JSValue js_get_attribute(JSContext *ctx, JSValue this_val,
                                 int argc, JSValue *argv) {
    if (argc < 1) return JS_NULL;
    Node *node = get_node(ctx, this_val);
    if (!node) return JS_NULL;
    std::string name = js_to_string(ctx, argv[0]);
    std::transform(name.begin(), name.end(), name.begin(), ::tolower);
    auto it = node->attributes.find(name);
    if (it == node->attributes.end()) return JS_NULL;
    return js_from_string(ctx, it->second);
}

static JSValue js_remove_attribute(JSContext *ctx, JSValue this_val,
                                    int argc, JSValue *argv) {
    if (argc < 1) return JS_UNDEFINED;
    Node *node = get_node(ctx, this_val);
    if (!node) return JS_UNDEFINED;
    std::string name = js_to_string(ctx, argv[0]);
    node->attributes.erase(name);
    return JS_UNDEFINED;
}

static JSValue js_append_child(JSContext *ctx, JSValue this_val,
                                int argc, JSValue *argv) {
    if (argc < 1) return JS_UNDEFINED;
    Node *parent = get_node(ctx, this_val);
    Node *child  = get_node(ctx, argv[0]);
    if (!parent || !child) return JS_UNDEFINED;
    // Find the shared_ptr for child by walking parent's children
    // (We can't reconstruct shared_ptr from raw pointer safely here,
    //  so we store it differently — for now just signal dirty)
    return JS_UNDEFINED;
}

static JSValue js_remove_child(JSContext *ctx, JSValue this_val,
                                int argc, JSValue *argv) {
    if (argc < 1) return JS_UNDEFINED;
    Node *parent = get_node(ctx, this_val);
    Node *child  = get_node(ctx, argv[0]);
    if (!parent || !child) return JS_UNDEFINED;
    parent->children.erase(
        std::remove_if(parent->children.begin(), parent->children.end(),
            [child](const std::shared_ptr<Node>& n) { return n.get() == child; }),
        parent->children.end());
    return JS_UNDEFINED;
}

static JSValue js_query_selector(JSContext *ctx, JSValue this_val,
                                  int argc, JSValue *argv,
                                  QJSEngine *engine) {
    if (argc < 1) return JS_NULL;
    Node *node = get_node(ctx, this_val);
    if (!node) {
        // Called on document — use dom_root
        node = engine->dom_root.get();
    }
    if (!node) return JS_NULL;

    std::string sel = js_to_string(ctx, argv[0]);
    // Use our existing query_selector via shared_from_this
    // We need to find the shared_ptr — walk from root
    std::function<std::shared_ptr<Node>(std::shared_ptr<Node>,Node*)> find_ptr;
    find_ptr = [&](std::shared_ptr<Node> cur, Node *raw) -> std::shared_ptr<Node> {
        if (cur.get() == raw) return cur;
        for (auto& c : cur->children) {
            auto r = find_ptr(c, raw);
            if (r) return r;
        }
        return nullptr;
    };

    auto node_sp = find_ptr(engine->dom_root, node);
    if (!node_sp) return JS_NULL;

    auto found = node_sp->query_selector(sel);
    if (!found) return JS_NULL;
    return wrap_node(ctx, found, engine);
}

// ── classList ──────────────────────────────────────────────────────────────
static JSValue make_classlist(JSContext *ctx, Node *node, QJSEngine *engine) {
    JSValue cl = JS_NewObject(ctx);

    // add(name)
    JS_SetPropertyStr(ctx, cl, "add",
        JS_NewCFunction(ctx, [](JSContext *c, JSValue this_v,
                                int ac, JSValue *av) -> JSValue {
            JSValue np = JS_GetPropertyStr(c, this_v, "_np");
            int64_t p = 0; JS_ToInt64(c, &p, np); JS_FreeValue(c, np);
            Node *nd = reinterpret_cast<Node*>((uintptr_t)p);
            if (!nd || ac < 1) return JS_UNDEFINED;
            std::string cls = js_to_string(c, av[0]);
            std::string& cur = nd->attributes["class"];
            if (cur.find(cls) == std::string::npos) {
                if (!cur.empty()) cur += " ";
                cur += cls;
            }
            return JS_UNDEFINED;
        }, "add", 1));

    // remove(name)
    JS_SetPropertyStr(ctx, cl, "remove",
        JS_NewCFunction(ctx, [](JSContext *c, JSValue this_v,
                                int ac, JSValue *av) -> JSValue {
            JSValue np = JS_GetPropertyStr(c, this_v, "_np");
            int64_t p = 0; JS_ToInt64(c, &p, np); JS_FreeValue(c, np);
            Node *nd = reinterpret_cast<Node*>((uintptr_t)p);
            if (!nd || ac < 1) return JS_UNDEFINED;
            std::string cls = " " + js_to_string(c, av[0]);
            std::string& cur = nd->attributes["class"];
            auto pos = cur.find(cls);
            if (pos != std::string::npos) cur.erase(pos, cls.size());
            else {
                cls = cls.substr(1); // try without leading space
                pos = cur.find(cls);
                if (pos != std::string::npos) cur.erase(pos, cls.size());
            }
            return JS_UNDEFINED;
        }, "remove", 1));

    // toggle(name)
    JS_SetPropertyStr(ctx, cl, "toggle",
        JS_NewCFunction(ctx, [](JSContext *c, JSValue this_v,
                                int ac, JSValue *av) -> JSValue {
            JSValue np = JS_GetPropertyStr(c, this_v, "_np");
            int64_t p = 0; JS_ToInt64(c, &p, np); JS_FreeValue(c, np);
            Node *nd = reinterpret_cast<Node*>((uintptr_t)p);
            if (!nd || ac < 1) return JS_FALSE;
            std::string cls = js_to_string(c, av[0]);
            std::string& cur = nd->attributes["class"];
            if (cur.find(cls) != std::string::npos) {
                // remove
                auto pos = cur.find(cls);
                cur.erase(pos, cls.size());
                return JS_FALSE;
            } else {
                if (!cur.empty()) cur += " ";
                cur += cls;
                return JS_TRUE;
            }
        }, "toggle", 1));

    // contains(name)
    JS_SetPropertyStr(ctx, cl, "contains",
        JS_NewCFunction(ctx, [](JSContext *c, JSValue this_v,
                                int ac, JSValue *av) -> JSValue {
            JSValue np = JS_GetPropertyStr(c, this_v, "_np");
            int64_t p = 0; JS_ToInt64(c, &p, np); JS_FreeValue(c, np);
            Node *nd = reinterpret_cast<Node*>((uintptr_t)p);
            if (!nd || ac < 1) return JS_FALSE;
            std::string cls = js_to_string(c, av[0]);
            std::string& cur = nd->attributes["class"];
            return cur.find(cls) != std::string::npos ? JS_TRUE : JS_FALSE;
        }, "contains", 1));

    JS_SetPropertyStr(ctx, cl, "_np",
        JS_NewInt64(ctx, (int64_t)(uintptr_t)node));
    return cl;
}

// ── Wrap a Node as a JS object ─────────────────────────────────────────────
static JSValue wrap_node(JSContext *ctx, std::shared_ptr<Node> node,
                          QJSEngine *engine) {
    if (!node) return JS_NULL;

    JSValue obj = JS_NewObjectClass(ctx, node_class_id);
    JS_SetOpaque(obj, node.get());

    Node *raw = node.get();

    // tagName
    JS_SetPropertyStr(ctx, obj, "tagName",
        js_from_string(ctx, raw->type == NodeType::Element ? raw->data : ""));

    // nodeType
    JS_SetPropertyStr(ctx, obj, "nodeType",
        JS_NewInt32(ctx, raw->type == NodeType::Element ? 1 : 3));

    // textContent / innerText (getter)
    std::string text;
    std::function<void(Node*)> collect_text = [&](Node *n) {
        if (!n) return;
        if (n->type == NodeType::Text) text += n->data;
        for (auto& c : n->children) collect_text(c.get());
    };
    collect_text(raw);
    JS_SetPropertyStr(ctx, obj, "textContent", js_from_string(ctx, text));
    JS_SetPropertyStr(ctx, obj, "innerText",   js_from_string(ctx, text));

    // innerHTML setter (simplified)
    // id, className
    {
        auto it = raw->attributes.find("id");
        JS_SetPropertyStr(ctx, obj, "id",
            js_from_string(ctx, it != raw->attributes.end() ? it->second : ""));
    }
    {
        auto it = raw->attributes.find("class");
        JS_SetPropertyStr(ctx, obj, "className",
            js_from_string(ctx, it != raw->attributes.end() ? it->second : ""));
    }

    // style object
    {
        JSValue style = JS_NewObject(ctx);
        JS_SetPropertyStr(ctx, style, "_np",
            JS_NewInt64(ctx, (int64_t)(uintptr_t)raw));
        JS_SetPropertyStr(ctx, style, "setProperty",
            JS_NewCFunction(ctx, js_style_set, "setProperty", 2));

        // Common style properties as getters/setters via defineProperty would
        // be ideal, but for compatibility just expose display/visibility directly
        auto it = raw->attributes.find("style");
        std::string inline_style = it != raw->attributes.end() ? it->second : "";
        // Parse display from inline style
        std::string display_val = "";
        auto dp = inline_style.find("display:");
        if (dp != std::string::npos) {
            size_t ds = dp + 8;
            size_t de = inline_style.find(';', ds);
            display_val = inline_style.substr(ds, de == std::string::npos ? de : de-ds);
            // trim
            display_val.erase(0, display_val.find_first_not_of(" \t"));
            display_val.erase(display_val.find_last_not_of(" \t")+1);
        }
        JS_SetPropertyStr(ctx, style, "display",
            js_from_string(ctx, display_val));
        JS_SetPropertyStr(ctx, obj, "style", style);
    }

    // classList
    JS_SetPropertyStr(ctx, obj, "classList",
        make_classlist(ctx, raw, engine));

    // Methods — use lambdas capturing engine
    JS_SetPropertyStr(ctx, obj, "setAttribute",
        JS_NewCFunction(ctx, js_set_attribute, "setAttribute", 2));
    JS_SetPropertyStr(ctx, obj, "getAttribute",
        JS_NewCFunction(ctx, js_get_attribute, "getAttribute", 1));
    JS_SetPropertyStr(ctx, obj, "removeAttribute",
        JS_NewCFunction(ctx, js_remove_attribute, "removeAttribute", 1));
    JS_SetPropertyStr(ctx, obj, "removeChild",
        JS_NewCFunction(ctx, js_remove_child, "removeChild", 1));

    // querySelector on element (simplified - returns null, full impl needs engine ptr)
    JS_SetPropertyStr(ctx, obj, "querySelector",
        JS_NewCFunction(ctx, [](JSContext *c, JSValue, int, JSValue*) -> JSValue {
            return JS_NULL;
        }, "querySelector", 1));

    // children array (simplified — just child element count)
    JSValue children = JS_NewArray(ctx);
    uint32_t ci = 0;
    for (auto& child : raw->children) {
        if (child && child->type == NodeType::Element) {
            JS_SetPropertyUint32(ctx, children, ci++,
                wrap_node(ctx, child, engine));
        }
    }
    JS_SetPropertyStr(ctx, obj, "children", children);
    JS_SetPropertyStr(ctx, obj, "childElementCount", JS_NewInt32(ctx, ci));

    return obj;
}

// ── Global console ─────────────────────────────────────────────────────────
static JSValue js_console_log(JSContext *ctx, JSValue this_val,
                               int argc, JSValue *argv) {
    std::cerr << "[JS] ";
    for (int i = 0; i < argc; i++) {
        if (i > 0) std::cerr << " ";
        size_t len;
        const char *str = JS_ToCStringLen(ctx, &len, argv[i]);
        if (str) { std::cerr << str; JS_FreeCString(ctx, str); }
        else      std::cerr << "[object]";
    }
    std::cerr << "\n";
    return JS_UNDEFINED;
}

// ── setTimeout stub (no event loop — call immediately) ─────────────────────
static JSValue js_set_timeout(JSContext *ctx, JSValue this_val,
                               int argc, JSValue *argv) {
    // Execute callback immediately (no actual timer)
    if (argc >= 1 && JS_IsFunction(ctx, argv[0])) {
        JSValue ret = JS_Call(ctx, argv[0], JS_UNDEFINED, 0, nullptr);
        JS_FreeValue(ctx, ret);
    }
    return JS_NewInt32(ctx, 0);
}

// ── Set up the global environment ──────────────────────────────────────────
static void setup_globals(JSContext *ctx, QJSEngine *engine) {
    JSValue global = JS_GetGlobalObject(ctx);

    // console
    JSValue console = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, console, "log",
        JS_NewCFunction(ctx, js_console_log, "log", 1));
    JS_SetPropertyStr(ctx, console, "warn",
        JS_NewCFunction(ctx, js_console_log, "warn", 1));
    JS_SetPropertyStr(ctx, console, "error",
        JS_NewCFunction(ctx, js_console_log, "error", 1));
    JS_SetPropertyStr(ctx, global, "console", console);

    // setTimeout / setInterval (stubs)
    JS_SetPropertyStr(ctx, global, "setTimeout",
        JS_NewCFunction(ctx, js_set_timeout, "setTimeout", 2));
    JS_SetPropertyStr(ctx, global, "setInterval",
        JS_NewCFunction(ctx, js_set_timeout, "setInterval", 2));
    JS_SetPropertyStr(ctx, global, "clearTimeout",
        JS_NewCFunction(ctx, [](JSContext*, JSValue, int, JSValue*) {
            return JS_UNDEFINED;
        }, "clearTimeout", 1));

    // location stub
    JSValue location = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, location, "href",   JS_NewString(ctx, ""));
    JS_SetPropertyStr(ctx, location, "hostname", JS_NewString(ctx, ""));
    JS_SetPropertyStr(ctx, global, "location", location);

    // navigator stub
    JSValue navigator = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, navigator, "userAgent",
        JS_NewString(ctx, "Mozilla/5.0 ScratchBrowser/1.0"));
    JS_SetPropertyStr(ctx, navigator, "language", JS_NewString(ctx, "en-US"));
    JS_SetPropertyStr(ctx, global, "navigator", navigator);

    // window = global
    JS_SetPropertyStr(ctx, global, "window", JS_DupValue(ctx, global));

    // document
    JSValue document = JS_NewObject(ctx);

    // document.querySelector
    // Store engine ptr so the lambda can access DOM
    auto *eng_ptr = engine;

    JS_SetPropertyStr(ctx, document, "querySelector",
        JS_NewCFunction(ctx, [](JSContext *c, JSValue this_v,
                                int ac, JSValue *av) -> JSValue {
            // Can't capture in C function; use opaque on document
            JSValue ep = JS_GetPropertyStr(c, this_v, "_engine");
            int64_t p = 0; JS_ToInt64(c, &p, ep); JS_FreeValue(c, ep);
            QJSEngine *eng = reinterpret_cast<QJSEngine*>((uintptr_t)p);
            if (!eng || ac < 1) return JS_NULL;
            std::string sel = js_to_string(c, av[0]);
            auto found = eng->dom_root->query_selector(sel);
            if (!found) return JS_NULL;
            eng->dom_dirty = true;
            return wrap_node(c, found, eng);
        }, "querySelector", 1));

    JS_SetPropertyStr(ctx, document, "querySelectorAll",
        JS_NewCFunction(ctx, [](JSContext *c, JSValue this_v,
                                int ac, JSValue *av) -> JSValue {
            JSValue ep = JS_GetPropertyStr(c, this_v, "_engine");
            int64_t p = 0; JS_ToInt64(c, &p, ep); JS_FreeValue(c, ep);
            QJSEngine *eng = reinterpret_cast<QJSEngine*>((uintptr_t)p);
            if (!eng || ac < 1) return JS_NewArray(c);
            std::string sel = js_to_string(c, av[0]);
            auto results = eng->dom_root->query_selector_all(sel);
            JSValue arr = JS_NewArray(c);
            for (uint32_t i = 0; i < results.size(); i++)
                JS_SetPropertyUint32(c, arr, i, wrap_node(c, results[i], eng));
            return arr;
        }, "querySelectorAll", 1));

    JS_SetPropertyStr(ctx, document, "getElementById",
        JS_NewCFunction(ctx, [](JSContext *c, JSValue this_v,
                                int ac, JSValue *av) -> JSValue {
            JSValue ep = JS_GetPropertyStr(c, this_v, "_engine");
            int64_t p = 0; JS_ToInt64(c, &p, ep); JS_FreeValue(c, ep);
            QJSEngine *eng = reinterpret_cast<QJSEngine*>((uintptr_t)p);
            if (!eng || ac < 1) return JS_NULL;
            std::string id = "#" + js_to_string(c, av[0]);
            auto found = eng->dom_root->query_selector(id);
            if (!found) return JS_NULL;
            eng->dom_dirty = true;
            return wrap_node(c, found, eng);
        }, "getElementById", 1));

    JS_SetPropertyStr(ctx, document, "createElement",
        JS_NewCFunction(ctx, [](JSContext *c, JSValue, int ac, JSValue *av)
                        -> JSValue {
            if (ac < 1) return JS_NULL;
            std::string tag = js_to_string(c, av[0]);
            std::transform(tag.begin(), tag.end(), tag.begin(), ::tolower);
            auto node = ElementNode(tag);
            // Leak intentional for JS-created nodes — they live until GC
            // In production, use a registry
            return JS_NULL; // simplified
        }, "createElement", 1));

    // document.body / document.head
    if (engine->dom_root) {
        auto body = engine->dom_root->query_selector("body");
        auto head = engine->dom_root->query_selector("head");
        if (body) JS_SetPropertyStr(ctx, document, "body",
                      wrap_node(ctx, body, engine));
        if (head) JS_SetPropertyStr(ctx, document, "head",
                      wrap_node(ctx, head, engine));
        JS_SetPropertyStr(ctx, document, "documentElement",
            wrap_node(ctx, engine->dom_root, engine));
    }

    // Store engine pointer in document for callbacks
    JS_SetPropertyStr(ctx, document, "_engine",
        JS_NewInt64(ctx, (int64_t)(uintptr_t)engine));

    JS_SetPropertyStr(ctx, global, "document", document);

    JS_FreeValue(ctx, global);
}

// ── Public API ─────────────────────────────────────────────────────────────

QJSEngine* qjs_create(std::shared_ptr<Node> dom_root) {
    // Register node class (once)
    if (!node_class_id)
        JS_NewClassID(&node_class_id);

    auto *engine = new QJSEngine();
    engine->dom_root = dom_root;

    engine->rt  = JS_NewRuntime();
    JS_SetMemoryLimit(engine->rt, 32 * 1024 * 1024); // 32MB heap

    engine->ctx = JS_NewContext(engine->rt);
    JS_NewClass(engine->rt, node_class_id, &node_class_def);

    setup_globals(engine->ctx, engine);
    return engine;
}

void qjs_destroy(QJSEngine *engine) {
    if (!engine) return;
    if (engine->ctx) JS_FreeContext(engine->ctx);
    if (engine->rt)  JS_FreeRuntime(engine->rt);
    delete engine;
}

std::string qjs_eval(QJSEngine *engine, const std::string& source,
                     const std::string& filename) {
    if (!engine || source.empty()) return "";

    JSValue result = JS_Eval(engine->ctx,
        source.c_str(), source.size(),
        filename.c_str(),
        JS_EVAL_TYPE_GLOBAL | JS_EVAL_FLAG_STRICT);

    std::string error;
    if (JS_IsException(result)) {
        JSValue ex = JS_GetException(engine->ctx);
        JSValue msg = JS_GetPropertyStr(engine->ctx, ex, "message");
        error = js_to_string(engine->ctx, msg);
        JS_FreeValue(engine->ctx, msg);
        JS_FreeValue(engine->ctx, ex);
    }

    JS_FreeValue(engine->ctx, result);


    engine->dom_dirty = true; // assume DOM may have changed
    return error;
}

void qjs_run_scripts(QJSEngine *engine, std::shared_ptr<Node> root) {
    if (!engine || !root) return;

    std::function<void(std::shared_ptr<Node>)> run;
    run = [&](std::shared_ptr<Node> node) {
        if (!node) return;
        if (node->type == NodeType::Element && node->data == "script") {
            // Skip external scripts (src attribute) — we don't fetch them yet
            if (node->attributes.count("src")) {
                std::cerr << "[JS] Skipping external script: "
                          << node->attributes["src"] << "\n";
                return;
            }
            std::string source;
            for (auto& c : node->children)
                if (c && c->type == NodeType::Text)
                    source += c->data;
            if (!source.empty()) {
                std::string err = qjs_eval(engine, source, "<script>");
                if (!err.empty())
                    std::cerr << "[JS ERROR] " << err << "\n";
            }
            return;
        }
        for (auto& c : node->children) run(c);
    };
    run(root);
}

void qjs_call_global(QJSEngine *engine, const std::string& name) {
    if (!engine) return;
    JSValue global = JS_GetGlobalObject(engine->ctx);
    JSValue fn = JS_GetPropertyStr(engine->ctx, global, name.c_str());
    if (JS_IsFunction(engine->ctx, fn)) {
        JSValue ret = JS_Call(engine->ctx, fn, global, 0, nullptr);
        JS_FreeValue(engine->ctx, ret);
    }
    JS_FreeValue(engine->ctx, fn);
    JS_FreeValue(engine->ctx, global);
}

bool qjs_dom_dirty(QJSEngine *engine) {
    return engine && engine->dom_dirty;
}

void qjs_clear_dirty(QJSEngine *engine) {
    if (engine) engine->dom_dirty = false;
}
