#include "style.h"
#include <algorithm>
#include <sstream>
#include <unordered_map>

using NodePtr = std::shared_ptr<Node>;

static std::string lower(std::string s) {
  std::transform(s.begin(), s.end(), s.begin(), ::tolower);
  return s;
}

// No longer need parent_map or build_parent_map since Node contains parent pointers

/* =============================
   Specificity
   ============================= */

struct Specificity {
  int a = 0; // id
  int b = 0; // class, attribute, pseudo
  int c = 0; // tag

  bool operator>(const Specificity &o) const {
    if (a != o.a)
      return a > o.a;
    if (b != o.b)
      return b > o.b;
    return c > o.c;
  }
};

static Specificity calc_spec(const SimpleSelector &sel) {

  Specificity s;

  if (!sel.id.empty())
    s.a++;

  s.b += sel.classes.size();

  if (!sel.tag_name.empty())
    s.c++;

  return s;
}

/* =============================
   Class matching
   ============================= */

static bool class_match(const std::string &elem_classes,
                        const std::vector<std::string> &selector_classes) {

  std::istringstream iss(elem_classes);
  std::string token;

  std::vector<std::string> classes;

  while (iss >> token)
    classes.push_back(token);

  for (auto &cls : selector_classes) {

    bool found = false;

    for (auto &c : classes) {
      if (c == cls) {
        found = true;
        break;
      }
    }

    if (!found)
      return false;
  }

  return true;
}

/* =============================
   Attribute selectors
   ============================= */

static bool match_attr(NodePtr elem, const std::string &name,
                       const std::string &value) {

  auto it = elem->attributes.find(name);

  if (it == elem->attributes.end())
    return false;

  if (!value.empty())
    return it->second == value;

  return true;
}

/* =============================
   nth-child
   ============================= */

static int child_index(NodePtr node) {
  auto parent = node->parent.lock();
  if (!parent)
    return -1;

  int index = 1;
  for (auto &c : parent->children) {
    if (c.get() == node.get())
      return index;
    index++;
  }
  return -1;
}

/* =============================
   Simple selector match
   ============================= */

static bool match_simple(NodePtr elem, const SimpleSelector &sel) {

  if (!elem || elem->type != NodeType::Element)
    return false;

  if (!sel.tag_name.empty()) {

    if (lower(elem->data) != lower(sel.tag_name))
      return false;
  }

  if (!sel.id.empty()) {

    auto it = elem->attributes.find("id");

    if (it == elem->attributes.end())
      return false;

    if (it->second != sel.id)
      return false;
  }

  if (!sel.classes.empty()) {

    auto it = elem->attributes.find("class");

    if (it == elem->attributes.end())
      return false;

    if (!class_match(it->second, sel.classes))
      return false;
  }

  return true;
}

/* =============================
   Descendant selector
   div p
   ============================= */

static bool match_descendant(NodePtr elem, const SimpleSelector &sel) {
  auto parent = elem->parent.lock();
  while (parent) {
    if (parent->type == NodeType::Element) {
      if (lower(parent->data) == lower(sel.tag_name))
        return true;
    }
    parent = parent->parent.lock();
  }
  return false;
}

/* =============================
   Child selector
   div > p
   ============================= */

static bool match_child(NodePtr elem, const SimpleSelector &sel) {
  auto parent = elem->parent.lock();
  if (!parent || parent->type != NodeType::Element)
    return false;

  return lower(parent->data) == lower(sel.tag_name);
}

/* =============================
   Adjacent selector
   div + p
   ============================= */

static bool match_adjacent(NodePtr elem, const SimpleSelector &sel) {
  auto prev = elem->prev_sibling.lock();
  if (!prev || prev->type != NodeType::Element)
    return false;

  return lower(prev->data) == lower(sel.tag_name);
}

// rule index
struct RuleIndex {

  std::unordered_map<std::string, std::vector<const Rule *>> tag_rules;
  std::unordered_map<std::string, std::vector<const Rule *>> class_rules;
  std::unordered_map<std::string, std::vector<const Rule *>> id_rules;

  std::vector<const Rule *> universal_rules;
};

static RuleIndex build_rule_index(const Stylesheet &sheet) {

  RuleIndex index;

  for (const auto &rule : sheet.rules) {

    for (const auto &sel : rule.selectors) {
      if (sel.components.empty()) continue;
      const auto& last = sel.components.back();

      if (!last.id.empty()) {
        index.id_rules[last.id].push_back(&rule);
      } else if (!last.classes.empty()) {
        for (auto &c : last.classes)
          index.class_rules[c].push_back(&rule);
      } else if (!last.tag_name.empty()) {
        index.tag_rules[lower(last.tag_name)].push_back(&rule);
      } else {
        index.universal_rules.push_back(&rule);
      }
    }
  }

  return index;
}

static void gather_rules(NodePtr elem, const RuleIndex &index,
                         std::vector<const Rule *> &out) {
  if (!elem || elem->type != NodeType::Element)
    return;

  auto id_it = elem->attributes.find("id");

  if (id_it != elem->attributes.end()) {

    auto it = index.id_rules.find(id_it->second);

    if (it != index.id_rules.end())
      out.insert(out.end(), it->second.begin(), it->second.end());
  }

  auto class_it = elem->attributes.find("class");

  if (class_it != elem->attributes.end()) {

    std::stringstream ss(class_it->second);

    std::string c;

    while (ss >> c) {

      auto it = index.class_rules.find(c);

      if (it != index.class_rules.end())
        out.insert(out.end(), it->second.begin(), it->second.end());
    }
  }

  auto tag_it = index.tag_rules.find(lower(elem->data));

  if (tag_it != index.tag_rules.end())
    out.insert(out.end(), tag_it->second.begin(), tag_it->second.end());

  out.insert(out.end(), index.universal_rules.begin(),
             index.universal_rules.end());
}

/* =============================
   Rule match
   ============================= */

static bool match_selector(NodePtr elem, const Selector &sel) {
  if (sel.components.empty()) return false;
  
  auto curr = elem;
  for (int i = (int)sel.components.size() - 1; i >= 0; --i) {
    const auto& comp = sel.components[i];
    
    if (i == (int)sel.components.size() - 1) {
      if (!match_simple(curr, comp)) return false;
    } else {
      // The relationship to the NEXT component (i+1) is stored in that component
      Combinator comb = sel.components[i + 1].combinator;
      
      if (comb == Combinator::Child) {
        curr = curr->parent.lock();
        if (!curr || !match_simple(curr, comp)) return false;
      } else if (comb == Combinator::Descendant) {
        bool found = false;
        curr = curr->parent.lock();
        while (curr) {
          if (match_simple(curr, comp)) {
            found = true;
            break;
          }
          curr = curr->parent.lock();
        }
        if (!found) return false;
      } else if (comb == Combinator::Adjacent) {
        curr = curr->prev_sibling.lock();
        if (!curr || !match_simple(curr, comp)) return false;
      } else if (comb == Combinator::Sibling) {
        bool found = false;
        curr = curr->prev_sibling.lock();
        while (curr) {
          if (match_simple(curr, comp)) {
            found = true;
            break;
          }
          curr = curr->prev_sibling.lock();
        }
        if (!found) return false;
      } else {
          // Should not happen with valid selectors
          if (!match_simple(curr, comp)) return false;
      }
    }
  }
  return true;
}

bool matches_rule(NodePtr elem, const Rule &rule) {

  for (const auto &sel : rule.selectors) {
    if (match_selector(elem, sel))
      return true;
  }

  return false;
}

/* =============================
   Rule application
   ============================= */

PropertyMap match_rules(NodePtr elem, const Stylesheet &sheet,
                        const RuleIndex &index) {
  PropertyMap styles;

  std::vector<const Rule *> candidates;
  gather_rules(elem, index, candidates);
  
  // Sort by specificity and order (implicit in candidates list order)
  struct MatchedRule {
    const Rule* rule;
    int specificity;
  };
  std::vector<MatchedRule> matched;
  
  for (auto rule : candidates) {
    int max_spec = -1;
    bool any_match = false;
    for (const auto& sel : rule->selectors) {
      if (match_selector(elem, sel)) {
        any_match = true;
        max_spec = std::max(max_spec, sel.specificity());
      }
    }
    if (any_match) {
      matched.push_back({rule, max_spec});
    }
  }
  
  // Stable sort to maintain source order for same specificity
  std::stable_sort(matched.begin(), matched.end(), [](const MatchedRule& a, const MatchedRule& b) {
    return a.specificity < b.specificity;
  });

  for (auto& m : matched) {
    for (auto &decl : m.rule->declarations) {
      // Trim whitespace from values so "#fff\n" parses correctly
      std::string val = decl.value;
      size_t vs = val.find_first_not_of(" \t\r\n");
      size_t ve = val.find_last_not_of(" \t\r\n");
      if (vs != std::string::npos) val = val.substr(vs, ve - vs + 1);
      styles[decl.name] = val;
    }
  }

  return styles;
}

/* =============================
   Style tree
   ============================= */
static std::shared_ptr<StyledNode> style_tree(std::shared_ptr<Node> root,
                                              const Stylesheet &stylesheet,
                                              const RuleIndex &index,
                                              const std::shared_ptr<StyledNode>& parent,
                                              int depth,
                                              const Stylesheet *hover_sheet  = nullptr,
                                              const RuleIndex  *hover_index  = nullptr,
                                              const Stylesheet *focus_sheet  = nullptr,
                                              const RuleIndex  *focus_index  = nullptr) {

  if (!root)
    return nullptr;

  if (depth > 200)
    return std::make_shared<StyledNode>(root);

  auto node = std::make_shared<StyledNode>(root);
  node->parent = parent;

  if (root->type == NodeType::Element) {
    node->specified_values = match_rules(root, stylesheet, index);

    // Apply :hover rules if this element is currently hovered
    if (hover_sheet && hover_index && root->attributes.count("__hover")) {
      PropertyMap hover_vals = match_rules(root, *hover_sheet, *hover_index);
      for (auto& kv : hover_vals)
        node->specified_values[kv.first] = kv.second;
    }
    // Apply :focus rules if this element is focused
    if (focus_sheet && focus_index && root->attributes.count("__focus")) {
      PropertyMap focus_vals = match_rules(root, *focus_sheet, *focus_index);
      for (auto& kv : focus_vals)
        node->specified_values[kv.first] = kv.second;
    }
    
    // Parse inline style attribute
    auto it = root->attributes.find("style");
    if (it != root->attributes.end()) {
        std::stringstream ss(it->second);
        std::string decl;
        while (std::getline(ss, decl, ';')) {
            size_t colon = decl.find(':');
            if (colon != std::string::npos) {
                std::string name = decl.substr(0, colon);
                std::string value = decl.substr(colon + 1);
                name.erase(0, name.find_first_not_of(" \t\r\n"));
                name.erase(name.find_last_not_of(" \t\r\n") + 1);
                value.erase(0, value.find_first_not_of(" \t\r\n"));
                value.erase(value.find_last_not_of(" \t\r\n") + 1);
                if (!name.empty()) node->specified_values[name] = value;
            }
        }
    }

    // ── Resolve CSS custom properties (var()) and calc() ──────────────────
    // This runs after both stylesheet rules AND inline styles are applied,
    // so var() references in either context get resolved correctly.
    {
        auto& sv = node->specified_values;

        // ── Step 1: Collect all --custom-property values from this node
        // and walk up the ancestor chain (inheritance).
        std::unordered_map<std::string, std::string> custom_props;

        // Walk ancestors to collect inherited custom properties
        auto ancestor = parent;
        while (ancestor) {
            for (auto& kv : ancestor->specified_values) {
                if (kv.first.size() > 2 && kv.first[0] == '-' && kv.first[1] == '-') {
                    // Don't overwrite — closer ancestor wins (already added)
                    if (!custom_props.count(kv.first))
                        custom_props[kv.first] = kv.second;
                }
            }
            ancestor = ancestor->parent.lock();
        }
        // Current node's own custom props override ancestors
        for (auto& kv : sv) {
            if (kv.first.size() > 2 && kv.first[0] == '-' && kv.first[1] == '-')
                custom_props[kv.first] = kv.second;
        }

        // ── Step 2: Resolve var(--name, fallback) in all property values
        auto resolve_var = [&](const std::string& val) -> std::string {
            if (val.find("var(") == std::string::npos) return val;
            std::string result;
            size_t i = 0;
            while (i < val.size()) {
                size_t vp = val.find("var(", i);
                if (vp == std::string::npos) { result += val.substr(i); break; }
                result += val.substr(i, vp - i);
                // find matching closing paren (handles nested)
                size_t start = vp + 4;
                int depth = 1;
                size_t j = start;
                while (j < val.size() && depth > 0) {
                    if (val[j] == '(') depth++;
                    else if (val[j] == ')') depth--;
                    if (depth > 0) j++;
                    else break;
                }
                std::string inner = val.substr(start, j - start);
                i = j + 1; // past closing )

                // Split inner into name and optional fallback at first comma
                std::string var_name, fallback;
                size_t comma = inner.find(',');
                if (comma != std::string::npos) {
                    var_name = inner.substr(0, comma);
                    fallback = inner.substr(comma + 1);
                    // trim
                    var_name.erase(0, var_name.find_first_not_of(" \t"));
                    var_name.erase(var_name.find_last_not_of(" \t") + 1);
                    fallback.erase(0, fallback.find_first_not_of(" \t"));
                    fallback.erase(fallback.find_last_not_of(" \t") + 1);
                } else {
                    var_name = inner;
                    var_name.erase(0, var_name.find_first_not_of(" \t"));
                    var_name.erase(var_name.find_last_not_of(" \t") + 1);
                }

                auto it = custom_props.find(var_name);
                if (it != custom_props.end() && !it->second.empty())
                    result += it->second;
                else if (!fallback.empty())
                    result += fallback;
                // else: unresolved var() — emit nothing (property will be empty)
            }
            return result;
        };

        // Apply var() resolution to all non-custom properties
        for (auto& kv : sv) {
            if (kv.first.size() > 2 && kv.first[0] == '-' && kv.first[1] == '-')
                continue; // skip custom properties themselves
            if (kv.second.find("var(") != std::string::npos)
                kv.second = resolve_var(kv.second);
        }

        // ── Step 3: Resolve calc() expressions
        // Supports: calc(Apx + Bpx), calc(A% + Bpx), calc(100% - Npx),
        //           calc(N * X), calc(A / B), nested calc()
        auto resolve_calc = [&](const std::string& val,
                                float percentage_basis) -> std::string {
            if (val.find("calc(") == std::string::npos) return val;

            // Find and replace each calc(...) occurrence
            std::string result;
            size_t i = 0;
            while (i < val.size()) {
                size_t cp = val.find("calc(", i);
                if (cp == std::string::npos) { result += val.substr(i); break; }
                result += val.substr(i, cp - i);
                size_t start = cp + 5;
                int depth = 1;
                size_t j = start;
                while (j < val.size() && depth > 0) {
                    if (val[j] == '(') depth++;
                    else if (val[j] == ')') depth--;
                    if (depth > 0) j++;
                    else break;
                }
                std::string expr = val.substr(start, j - start);
                i = j + 1;

                // Tokenize and evaluate: supports +, -, *, /
                // Convert tokens to px values then compute
                auto to_px = [&](const std::string& tok) -> float {
                    if (tok.empty()) return 0.f;
                    try {
                        if (tok.size() > 2 && tok.substr(tok.size()-2) == "px")
                            return std::stof(tok);
                        if (tok.size() > 2 && tok.substr(tok.size()-2) == "em")
                            return std::stof(tok) * 16.f; // assume 16px base
                        if (tok.size() > 3 && tok.substr(tok.size()-3) == "rem")
                            return std::stof(tok) * 16.f;
                        if (!tok.empty() && tok.back() == '%')
                            return std::stof(tok) * percentage_basis / 100.f;
                        return std::stof(tok); // bare number
                    } catch (...) { return 0.f; }
                };

                // Simple left-to-right evaluator (handles +/-/* //)
                // Tokenize by spaces around operators
                std::vector<std::string> tokens;
                std::string tok;
                for (char c : expr) {
                    if (c == ' ') {
                        if (!tok.empty()) { tokens.push_back(tok); tok.clear(); }
                    } else {
                        tok += c;
                    }
                }
                if (!tok.empty()) tokens.push_back(tok);

                float acc = 0.f;
                char op = '+';
                for (auto& t : tokens) {
                    if (t == "+" || t == "-" || t == "*" || t == "/") {
                        op = t[0];
                    } else {
                        float v = to_px(t);
                        switch (op) {
                            case '+': acc += v; break;
                            case '-': acc -= v; break;
                            case '*': acc *= v; break;
                            case '/': if (v != 0) acc /= v; break;
                        }
                        op = '+'; // reset to + after first operand consumed
                    }
                }
                // Emit as px
                result += std::to_string((int)acc) + "px";
            }
            return result;
        };

        // Apply calc() to dimensional properties
        // Use 100% as default percentage basis (layout will refine later)
        static const char* calc_props[] = {
            "width", "height", "min-width", "min-height", "max-width", "max-height",
            "margin", "margin-top", "margin-right", "margin-bottom", "margin-left",
            "padding", "padding-top", "padding-right", "padding-bottom", "padding-left",
            "top", "right", "bottom", "left", "gap", "font-size", nullptr
        };
        for (int pi = 0; calc_props[pi]; pi++) {
            auto it = sv.find(calc_props[pi]);
            if (it != sv.end() && it->second.find("calc(") != std::string::npos)
                it->second = resolve_calc(it->second, 100.f);
        }
    }

    // ── Expand CSS shorthands ──────────────────────────────────────────────
    auto& sv = node->specified_values;

    // Helper: split a shorthand value into up to 4 space-separated tokens
    auto split_vals = [](const std::string& v) {
        std::vector<std::string> parts;
        std::stringstream ss(v);
        std::string t;
        while (ss >> t) parts.push_back(t);
        return parts;
    };

    // margin shorthand -> margin-top/right/bottom/left
    // Always expand (even if longhands exist) so later rules override earlier ones
    if (sv.count("margin")) {
        auto p = split_vals(sv["margin"]);
        if (p.size() == 1) {
            sv["margin-top"] = sv["margin-right"] = sv["margin-bottom"] = sv["margin-left"] = p[0];
        } else if (p.size() == 2) {
            sv["margin-top"] = sv["margin-bottom"] = p[0];
            sv["margin-left"] = sv["margin-right"] = p[1];
        } else if (p.size() == 3) {
            sv["margin-top"] = p[0];
            sv["margin-left"] = sv["margin-right"] = p[1];
            sv["margin-bottom"] = p[2];
        } else if (p.size() >= 4) {
            sv["margin-top"] = p[0]; sv["margin-right"] = p[1];
            sv["margin-bottom"] = p[2]; sv["margin-left"] = p[3];
        }
    }

    // padding shorthand -> padding-top/right/bottom/left
    // Always expand (even if longhands exist) so later rules override earlier ones
    if (sv.count("padding")) {
        auto p = split_vals(sv["padding"]);
        if (p.size() == 1) {
            sv["padding-top"] = sv["padding-right"] = sv["padding-bottom"] = sv["padding-left"] = p[0];
        } else if (p.size() == 2) {
            sv["padding-top"] = sv["padding-bottom"] = p[0];
            sv["padding-left"] = sv["padding-right"] = p[1];
        } else if (p.size() == 3) {
            sv["padding-top"] = p[0];
            sv["padding-left"] = sv["padding-right"] = p[1];
            sv["padding-bottom"] = p[2];
        } else if (p.size() >= 4) {
            sv["padding-top"] = p[0]; sv["padding-right"] = p[1];
            sv["padding-bottom"] = p[2]; sv["padding-left"] = p[3];
        }
    }

    // font shorthand: extract font-size (and font-family if present)
    // Format: [style] [weight] size[/line-height] family
    if (sv.count("font") && !sv.count("font-size")) {
        auto p = split_vals(sv["font"]);
        for (const auto& tok : p) {
            if (tok.back() == '%' || (tok.find("px") != std::string::npos)
                || (tok.find("em") != std::string::npos)
                || (tok.find("pt") != std::string::npos)) {
                // strip /line-height
                std::string sz = tok.substr(0, tok.find('/'));
                sv["font-size"] = sz;
                break;
            }
            if (tok == "bold" || tok == "bolder") sv["font-weight"] = "bold";
            if (tok == "italic") sv["font-style"] = "italic";
        }
    }

    // background shorthand: if background-color not set, try to extract a color
    if (sv.count("background") && !sv.count("background-color")) {
        const std::string& bg = sv["background"];
        auto p = split_vals(bg);
        for (const auto& tok : p) {
            if (tok[0] == '#' || tok.rfind("rgb", 0) == 0) {
                sv["background-color"] = tok;
                break;
            }
            if (tok == "white" || tok == "black" || tok == "transparent" ||
                tok == "red" || tok == "green" || tok == "blue") {
                sv["background-color"] = tok;
                break;
            }
        }
    }

    // Note: visibility:hidden intentionally NOT mapped to display:none
    // because Google's search bar is visibility:hidden by default and
    // shown via JS — if we hide it, the search bar disappears entirely.

    // overflow:hidden on zero-height containers — don't hide content, just ignore
    // (we don't clip, so this is a no-op)
  }

  for (auto &child : root->children)
    node->children.push_back(style_tree(child, stylesheet, index, node,
                                         depth + 1,
                                         hover_sheet, hover_index,
                                         focus_sheet, focus_index));

  return node;
}

std::shared_ptr<StyledNode> build_style_tree(NodePtr root,
                                             const Stylesheet &stylesheet,
                                             const Stylesheet *hover_sheet,
                                             const Stylesheet *focus_sheet) {
  RuleIndex index = build_rule_index(stylesheet);

  // Build optional hover/focus indexes
  RuleIndex hover_idx, focus_idx;
  if (hover_sheet) hover_idx = build_rule_index(*hover_sheet);
  if (focus_sheet) focus_idx = build_rule_index(*focus_sheet);

  return style_tree(root, stylesheet, index, nullptr, 0,
                    hover_sheet  ? hover_sheet  : nullptr,
                    hover_sheet  ? &hover_idx   : nullptr,
                    focus_sheet  ? focus_sheet  : nullptr,
                    focus_sheet  ? &focus_idx   : nullptr);
}
