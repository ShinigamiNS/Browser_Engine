#include "layout.h"
#include "font_metrics.h"
#include <algorithm>
#include <functional>
#include <iostream>
#include <sstream>
#include <map>
#include <string>
#include <vector>

static bool is_display_none(const std::shared_ptr<StyledNode> &style) {
  if (!style)
    return false;

  auto it = style->specified_values.find("display");
  if (it == style->specified_values.end())
    return false;

  return it->second == "none";
}

/* Inline element detection */

// Forward declaration
static void offset_children(LayoutBox *box, float dx, float dy);

static bool is_inline_tag(const std::string &tag) {

  static const std::vector<std::string> inline_tags = {
      "span", "a", "b",    "strong", "em",   "img", "input", "label", "small",
      "i",    "u", "code", "abbr",   "cite", "q",   "sub",   "sup"};

  for (const auto &t : inline_tags)
    if (t == tag)
      return true;

  return false;
}

static float estimate_text_width(const std::string &text) {
  return text.length() * 8.0f; // simple font estimate
}

/* CSS value parsing */

static float parse_px(const std::string &v, float relative_to = 0) {
  if (v.empty() || v == "auto")
    return 0;

  try {
    if (v.back() == '%') {
      return (relative_to * std::stof(v.substr(0, v.length() - 1))) / 100.0f;
    }
    return std::stof(v);
  } catch (...) {
    return 0;
  }
}

static float style_value(const PropertyMap &map, const std::string &key,
                         float def, float relative_to = 0) {

  auto it = map.find(key);

  if (it == map.end())
    return def;

  return parse_px(it->second, relative_to);
}

/* Layout entry */

void LayoutBox::layout(Dimensions containing_block) {
  auto &style = style_node->specified_values;
  std::string pos = style.count("position") ? style.at("position") : "static";

  // Fixed elements are positioned relative to the viewport, not the document
  // flow.
  if (pos == "fixed") {
    // For fixed elements, containing_block.width is the viewport width.
    // We need the real viewport HEIGHT — store it in content.x temporarily via
    // a convention: The caller sets viewport.content.height=0 for the root, but
    // passes real height via a separate field. We use the original
    // containing_block's content.width as a proxy for viewport width, and
    // re-use content.height=0 means we must fall back to a reasonable value.
    // Use the parent's content.width as viewport width (correct), and for
    // height use 768 default since the viewport height is not reliably passed
    // through.
    float vp_w = containing_block.content.width;
    // Use the real viewport height via extern global set in main.cpp
    extern int g_viewport_height;
    float vp_h = g_viewport_height > 0 ? (float)g_viewport_height : 768.0f;

    Dimensions viewport;
    viewport.content.x = 0;
    viewport.content.y = 0;
    viewport.content.width = vp_w;
    viewport.content.height = 0;
    calculate_block_width(viewport);

    float left = style.count("left") ? parse_px(style.at("left"), vp_w) : 0;
    float top = style.count("top") ? parse_px(style.at("top"), vp_h) : 0;
    float right = style.count("right") ? parse_px(style.at("right"), vp_w) : -1;
    float bottom =
        style.count("bottom") ? parse_px(style.at("bottom"), vp_h) : -1;
    dimensions.content.x =
        (right >= 0) ? vp_w - dimensions.content.width - right : left;
    dimensions.content.y =
        (bottom >= 0) ? vp_h - dimensions.content.height - bottom : top;
    layout_block_children();
    calculate_block_height();
    return; // fixed elements do NOT contribute to normal flow height
  }

  // Inline elements: position is set by parent's inline flow, not
  // calculate_block_position
  bool is_inline = (box_type == BoxType::InlineNode);

  // Some tags are always treated as inline containers
  if (!is_inline && style_node && style_node->node &&
      style_node->node->type == NodeType::Element) {
    std::string tag = style_node->node->data;
    if (tag == "span" || tag == "a" || tag == "b" || tag == "strong" ||
        tag == "em" || tag == "i" || tag == "u" || tag == "label" ||
        tag == "abbr" || tag == "code" || tag == "small" || tag == "sub" ||
        tag == "sup")
      is_inline = true;
  }

  if (is_inline) {
    // Inline elements: width shrinks to content, position set by parent's flow
    // For img: use width/height attributes, then style, then default
    if (style_node->node && style_node->node->type == NodeType::Element &&
        style_node->node->data == "img") {
      float iw = 0, ih = 0;
      auto &attrs = style_node->node->attributes;
      if (attrs.count("width"))
        iw = (float)atof(attrs.at("width").c_str());
      if (attrs.count("height"))
        ih = (float)atof(attrs.at("height").c_str());
      if (style.count("width"))
        iw = parse_px(style.at("width"), containing_block.content.width);
      if (style.count("height"))
        ih = parse_px(style.at("height"), containing_block.content.height);
      dimensions.content.width =
          iw > 0 ? iw : 24; // default small if no size given
      dimensions.content.height = ih > 0 ? ih : 24;
      return;
    }
    // Non-img inline elements: only set width from style if explicitly given
    if (style.count("width"))
      dimensions.content.width =
          parse_px(style.at("width"), containing_block.content.width);
    if (style.count("height"))
      dimensions.content.height =
          parse_px(style.at("height"), containing_block.content.height);
    // Apply padding
    dimensions.padding.left =
        style_value(style, "padding-left", 0, containing_block.content.width);
    dimensions.padding.right =
        style_value(style, "padding-right", 0, containing_block.content.width);
    dimensions.padding.top =
        style_value(style, "padding-top", 0, containing_block.content.width);
    dimensions.padding.bottom =
        style_value(style, "padding-bottom", 0, containing_block.content.width);
    dimensions.margin.left =
        style_value(style, "margin-left", 0, containing_block.content.width);
    dimensions.margin.right =
        style_value(style, "margin-right", 0, containing_block.content.width);
    dimensions.margin.top =
        style_value(style, "margin-top", 0, containing_block.content.width);
    dimensions.margin.bottom =
        style_value(style, "margin-bottom", 0, containing_block.content.width);
    // Layout own children (text nodes etc) at relative (0,0)
    // Parent's flush_inline_run will set absolute position afterward
    dimensions.content.x = 0;
    dimensions.content.y = 0;
    layout_inline_children();
    return;
  } else if (box_type == BoxType::BlockNode) {
    calculate_block_width(containing_block);
    calculate_block_position(containing_block);
    layout_block_children();
    calculate_block_height();
  } else if (box_type == BoxType::FlexContainer) {
    calculate_block_width(containing_block);
    calculate_block_position(containing_block);

    // FIX: height:100% on root flex containers
    if (dimensions.content.height == 0 &&
        containing_block.content.height == 0) {
      extern int g_viewport_height;
      extern int g_viewport_width;

      if (g_viewport_height > 0) {
        dimensions.content.height = (float)g_viewport_height;
        dimensions.content.width = (float)g_viewport_width;
      }
    }

    bool is_column =
        style.count("flex-direction") && style.at("flex-direction") == "column";
    std::string justify = style.count("justify-content")
                              ? style.at("justify-content")
                              : "flex-start";

    // First pass: layout each child to get their intrinsic sizes
    // Use a temporary containing block with height=0 to get natural sizes
    Dimensions size_cb = dimensions;
    size_cb.content.height = 0;
    for (auto &child : children) {
      if (!child)
        continue;
      child->layout(size_cb);
    }

    float total_main_size = 0;
    float max_cross_size = 0;
    for (auto &child : children) {
      if (!child)
        continue;
      if (is_column) {
        total_main_size += child->dimensions.margin_box().height;
        max_cross_size =
            std::max(max_cross_size, child->dimensions.margin_box().width);
      } else {
        total_main_size += child->dimensions.margin_box().width;
        max_cross_size =
            std::max(max_cross_size, child->dimensions.margin_box().height);
      }
    }

    float cursor_main = is_column ? dimensions.content.y : dimensions.content.x;
    float main_container_size =
        is_column ? dimensions.content.height : dimensions.content.width;
    if (main_container_size == 0)
      main_container_size = total_main_size;

    if (justify == "center" && main_container_size > total_main_size)
      cursor_main += (main_container_size - total_main_size) / 2.0f;
    else if (justify == "space-between" && children.size() > 1 &&
             main_container_size > total_main_size) {
      // handled per-child below
    }

    float spacing = 0;
    if (justify == "space-between" && children.size() > 1 &&
        main_container_size > total_main_size)
      spacing = (main_container_size - total_main_size) /
                ((float)children.size() - 1);

    // Second pass: set final positions and propagate to children via
    // offset_children
    for (auto &child : children) {
      if (!child)
        continue;
      float old_x = child->dimensions.content.x;
      float old_y = child->dimensions.content.y;
      float new_x, new_y;
      if (is_column) {
        new_x = dimensions.content.x + child->dimensions.margin.left;
        new_y = cursor_main + child->dimensions.margin.top;
        cursor_main += child->dimensions.margin_box().height + spacing;
      } else {
        new_x = cursor_main + child->dimensions.margin.left;
        new_y = dimensions.content.y + child->dimensions.margin.top;
        cursor_main += child->dimensions.margin_box().width + spacing;
      }
      child->dimensions.content.x = new_x;
      child->dimensions.content.y = new_y;
      // Shift all children by the delta between old and new position
      float dx = new_x - old_x;
      float dy = new_y - old_y;
      if (dx != 0 || dy != 0)
        offset_children(child.get(), dx, dy);
    }

    if (is_column)
      dimensions.content.height = total_main_size;
    else
      dimensions.content.height = max_cross_size;
    calculate_block_height(); // apply explicit CSS height / min-height /
                              // height:100%

  } else if (box_type == BoxType::GridContainer) {
    calculate_block_width(containing_block);
    calculate_block_position(containing_block);

    int cols = 2;
    if (style.count("grid-template-columns")) {
      std::string val = style.at("grid-template-columns");
      cols = 1;
      for (char c : val)
        if (c == ' ')
          cols++;
    }

    float col_width = dimensions.content.width / (float)cols;
    float cursor_x = dimensions.content.x;
    float cursor_y = dimensions.content.y;
    float curr_row_height = 0;
    int col_idx = 0;

    for (auto &child : children) {
      Dimensions child_cb = dimensions;
      child_cb.content.width = col_width;
      child->layout(child_cb);

      child->dimensions.content.x = cursor_x + (float)col_idx * col_width;
      child->dimensions.content.y = cursor_y;

      curr_row_height =
          std::max(curr_row_height, child->dimensions.margin_box().height);
      col_idx++;
      if (col_idx >= cols) {
        col_idx = 0;
        cursor_y += curr_row_height;
        curr_row_height = 0;
      }
    }
    dimensions.content.height =
        (cursor_y - dimensions.content.y) + curr_row_height;
  }

  // Handle relative/absolute positioning offsets
  if (pos == "relative") {
    dimensions.content.x +=
        style_value(style, "left", 0, containing_block.content.width);
    dimensions.content.x -=
        style_value(style, "right", 0, containing_block.content.width);
    dimensions.content.y +=
        style_value(style, "top", 0, containing_block.content.height);
    dimensions.content.y -=
        style_value(style, "bottom", 0, containing_block.content.height);
  } else if (pos == "absolute") {
    dimensions.content.x =
        containing_block.content.x +
        style_value(style, "left", 0, containing_block.content.width);
    dimensions.content.y =
        containing_block.content.y +
        style_value(style, "top", 0, containing_block.content.height);
    if (style.count("right"))
      dimensions.content.x =
          containing_block.content.x + containing_block.content.width -
          dimensions.content.width -
          style_value(style, "right", 0, containing_block.content.width);
    if (style.count("bottom"))
      dimensions.content.y =
          containing_block.content.y + containing_block.content.height -
          dimensions.content.height -
          style_value(style, "bottom", 0, containing_block.content.height);
  }
}

/* Block width */

void LayoutBox::calculate_block_width(Dimensions containing_block) {

  auto &style = style_node->specified_values;

  float width = containing_block.content.width;

  if (style.count("width"))
    width = parse_px(style["width"], containing_block.content.width);

  dimensions.content.width = width;

  // margin-left / margin-right — support "auto" for centering
  std::string ml_str =
      style.count("margin-left") ? style.at("margin-left") : "0";
  std::string mr_str =
      style.count("margin-right") ? style.at("margin-right") : "0";

  bool ml_auto = (ml_str == "auto");
  bool mr_auto = (mr_str == "auto");

  dimensions.margin.left =
      ml_auto ? 0 : parse_px(ml_str, containing_block.content.width);
  dimensions.margin.right =
      mr_auto ? 0 : parse_px(mr_str, containing_block.content.width);

  // margin-top / margin-bottom
  dimensions.margin.top =
      style_value(style, "margin-top", 0, containing_block.content.width);
  dimensions.margin.bottom =
      style_value(style, "margin-bottom", 0, containing_block.content.width);

  dimensions.padding.left =
      style_value(style, "padding-left", 0, containing_block.content.width);
  dimensions.padding.right =
      style_value(style, "padding-right", 0, containing_block.content.width);
  dimensions.padding.top =
      style_value(style, "padding-top", 0, containing_block.content.width);
  dimensions.padding.bottom =
      style_value(style, "padding-bottom", 0, containing_block.content.width);

  // Box-sizing: border-box
  if (style.count("box-sizing") && style.at("box-sizing") == "border-box") {
    dimensions.content.width -=
        (dimensions.padding.left + dimensions.padding.right +
         dimensions.border.left + dimensions.border.right);
    if (dimensions.content.width < 0)
      dimensions.content.width = 0;
  }

  // Compute auto margins for centering (both auto = equal split)
  if (ml_auto && mr_auto) {
    float used = dimensions.content.width + dimensions.padding.left +
                 dimensions.padding.right + dimensions.border.left +
                 dimensions.border.right;
    float remaining = std::max(0.0f, containing_block.content.width - used);
    dimensions.margin.left = dimensions.margin.right = remaining / 2.0f;
  } else if (ml_auto) {
    float used = dimensions.content.width + dimensions.padding.left +
                 dimensions.padding.right + dimensions.border.left +
                 dimensions.border.right + dimensions.margin.right;
    dimensions.margin.left =
        std::max(0.0f, containing_block.content.width - used);
  } else if (mr_auto) {
    float used = dimensions.content.width + dimensions.padding.left +
                 dimensions.padding.right + dimensions.border.left +
                 dimensions.border.right + dimensions.margin.left;
    dimensions.margin.right =
        std::max(0.0f, containing_block.content.width - used);
  }
}

/* Position */

void LayoutBox::calculate_block_position(Dimensions containing_block) {

  auto &d = dimensions;

  d.content.x = containing_block.content.x + d.margin.left + d.padding.left;

  d.content.y = containing_block.content.y + containing_block.content.height +
                d.margin.top + d.padding.top;
}

static int get_font_size(const std::shared_ptr<StyledNode> &node) {
  if (!node)
    return 16;
  std::string fs = node->value("font-size");
  if (fs.empty()) {
    if (node->node && node->node->type == NodeType::Element) {
      std::string tag = node->node->data;
      if (tag == "h1")
        return 32;
      if (tag == "h2")
        return 24;
      if (tag == "h3")
        return 20;
      if (tag == "small")
        return 14;
    }
    return 16;
  }
  int size = atoi(fs.c_str());
  return size > 0 ? size : 16;
}

static bool get_font_weight_bold(const std::shared_ptr<StyledNode> &node) {
  if (!node)
    return false;
  std::string fw = node->value("font-weight");
  if (fw == "bold" || fw == "700" || fw == "800" || fw == "900")
    return true;

  if (node->node && node->node->type == NodeType::Element) {
    std::string tag = node->node->data;
    if (tag == "h1" || tag == "h2" || tag == "h3" || tag == "b" ||
        tag == "strong")
      return true;
  }
  return false;
}

/* Inline layout */

// ── CSS Line Box Model ────────────────────────────────────────────────────
// Each line is represented as a list of fragments (inline items placed on it).
// After all fragments on a line are known we do one baseline-alignment pass.

struct InlineFragment {
  LayoutBox *box   = nullptr;
  float      x     = 0;       // left edge (absolute)
  float      width = 0;       // fragment width
  float      ascent  = 0;     // distance from baseline to top of content
  float      descent = 0;     // distance from baseline to bottom of content
  float      line_height = 0; // css line-height for this fragment
  bool       is_text = false;
};

struct LineBox {
  std::vector<InlineFragment> frags;
  float x_start  = 0;   // left edge of line (= content.x of parent)
  float width    = 0;   // available width
  float height   = 0;   // final height after alignment
  float baseline = 0;   // y of baseline within the line (from top of line)
};

// Compute the CSS line-height for a box as a pixel value
static float css_line_height(LayoutBox *box, int fs) {
  if (!box || !box->style_node) return (float)fs * 1.4f;
  auto it = box->style_node->specified_values.find("line-height");
  if (it == box->style_node->specified_values.end()) return (float)fs * 1.4f;
  const std::string &v = it->second;
  if (v == "normal") return (float)fs * 1.4f;
  try {
    // bare number = multiplier
    if (!v.empty() && (isdigit((unsigned char)v[0]) || v[0] == '.') &&
        v.find("px") == std::string::npos &&
        v.find('%')  == std::string::npos) {
      return std::stof(v) * fs;
    }
    return parse_px(v, (float)fs);
  } catch (...) { return (float)fs * 1.4f; }
}

// Collapse whitespace in a text node's data per CSS white-space:normal rules
static std::string collapse_whitespace(const std::string &s) {
  std::string out;
  out.reserve(s.size());
  bool prev_sp = true; // trim leading space
  for (unsigned char c : s) {
    bool sp = (c == ' ' || c == '\t' || c == '\r' || c == '\n');
    if (sp) { if (!prev_sp) { out += ' '; prev_sp = true; } }
    else    { out += (char)c; prev_sp = false; }
  }
  return out;
}

// Break text into word-level tokens for line-breaking
// Returns pairs of (word_string, width_in_px)
static std::vector<std::pair<std::string,float>>
tokenize_words(const std::string &text, int fs, bool bold) {
  auto &fm = FontMetrics::get_instance();
  std::vector<std::pair<std::string,float>> tokens;
  std::istringstream ss(text);
  std::string word;
  while (ss >> word) {
    std::string w = word + " ";
    float width = fm.measure_text(w, fs, bold).width;
    tokens.push_back({w, width});
  }
  return tokens;
}

// Commit a finished LineBox: set final y positions for all fragments using
// baseline alignment, return the total line height consumed.
static float commit_line(LineBox &line, float line_y) {
  if (line.frags.empty()) return 0.f;

  // Find max ascent and max descent across all fragments
  float max_ascent  = 0.f;
  float max_descent = 0.f;
  for (auto &f : line.frags) {
    max_ascent  = std::max(max_ascent,  f.ascent);
    max_descent = std::max(max_descent, f.descent);
  }
  float line_height = max_ascent + max_descent;
  line.height   = line_height;
  line.baseline = max_ascent;

  // Position each fragment: baseline-align (top of content = baseline - ascent)
  for (auto &f : line.frags) {
    if (!f.box) continue;
    float top_offset = max_ascent - f.ascent; // push down to align baselines
    f.box->dimensions.content.x = f.x;
    f.box->dimensions.content.y = line_y + top_offset;
    // For inline elements, also shift all their children by the same delta
    // (their children were positioned relative to content origin)
    // offset_children is called after full placement
  }
  return line_height;
}

static void layout_inline_flow(LayoutBox *parent) {
  auto &fm = FontMetrics::get_instance();
  int   pfs  = get_font_size(parent->style_node);
  float max_x = parent->dimensions.content.x + parent->dimensions.content.width;
  float line_x = parent->dimensions.content.x; // left edge of each line
  float cursor_x = line_x;
  float cursor_y = parent->dimensions.content.y;

  LineBox current_line;
  current_line.x_start = line_x;
  current_line.width   = parent->dimensions.content.width;

  // Flush current line: apply baseline alignment, advance cursor_y
  auto flush_line = [&]() {
    if (current_line.frags.empty()) return;
    float h = commit_line(current_line, cursor_y);
    // Shift inline-element children to absolute coords after commit
    for (auto &f : current_line.frags) {
      if (f.box && !f.is_text) {
        float dx = f.box->dimensions.content.x - 0.f; // content.x is already set
        float dy = f.box->dimensions.content.y - 0.f;
        // Children were laid out with content origin at (0,0); shift them
        offset_children(f.box, f.box->dimensions.content.x,
                                f.box->dimensions.content.y);
        // But don't double-shift: if children already have absolute coords skip
        // (layout_inline_children sets them relative; we shift once here)
      }
    }
    cursor_y += h;
    cursor_x = line_x;
    current_line.frags.clear();
  };

  for (auto &child : parent->children) {
    if (!child) continue;

    bool is_text = child->style_node && child->style_node->node &&
                   child->style_node->node->type == NodeType::Text;

    // ── <br> — hard line break ────────────────────────────────────────────
    bool is_br = !is_text && child->style_node && child->style_node->node &&
                 child->style_node->node->data == "br";
    if (is_br) {
      // Add a zero-width fragment so the line gets the parent's line-height
      InlineFragment br_frag;
      br_frag.box        = child.get();
      br_frag.is_text    = false;
      br_frag.x          = cursor_x;
      br_frag.width      = 0;
      float lh = css_line_height(parent, pfs);
      br_frag.ascent     = (float)pfs * 0.8f;
      br_frag.descent    = lh - br_frag.ascent;
      br_frag.line_height= lh;
      current_line.frags.push_back(br_frag);
      flush_line();
      continue;
    }

    if (is_text) {
      int   fs   = get_font_size(child->style_node);
      bool  bold = get_font_weight_bold(child->style_node);
      float lh   = css_line_height(child, fs);
      // Ascent ≈ 80% of font-size (typical for Latin fonts)
      float ascent  = (float)fs * 0.8f;
      float descent = lh - ascent;

      std::string collapsed = collapse_whitespace(child->style_node->node->data);
      auto tokens = tokenize_words(collapsed, fs, bold);

      // Place this text node's box at the start of its first fragment on
      // the line.  We accumulate all words into one content rect per line
      // (simplified — good enough for correct wrapping and alignment).
      bool placed = false;
      float frag_x_start = cursor_x;
      float frag_width   = 0.f;

      for (auto &[word, w] : tokens) {
        // Wrap: if word doesn't fit and we're not at line start, break
        if (cursor_x + w > max_x + 0.5f &&
            cursor_x > line_x + 0.5f) {
          // Save current fragment for this text node before wrapping
          if (placed) {
            InlineFragment f;
            f.box         = child.get();
            f.is_text     = true;
            f.x           = frag_x_start;
            f.width       = frag_width;
            f.ascent      = ascent;
            f.descent     = descent;
            f.line_height = lh;
            current_line.frags.push_back(f);
          }
          flush_line();
          frag_x_start = cursor_x;
          frag_width   = 0.f;
          placed       = false;
        }
        if (!placed) {
          frag_x_start = cursor_x;
          placed = true;
        }
        frag_width += w;
        cursor_x   += w;
      }

      // Commit last fragment for this text node
      InlineFragment f;
      f.box         = child.get();
      f.is_text     = true;
      f.x           = frag_x_start;
      f.width       = frag_width;
      f.ascent      = ascent;
      f.descent     = descent;
      f.line_height = lh;
      // Set box dimensions now (commit_line will set y)
      child->dimensions.content.x      = frag_x_start;
      child->dimensions.content.width  = frag_width;
      child->dimensions.content.height = (float)fs;
      current_line.frags.push_back(f);

    } else {
      // ── Inline replaced/element child ────────────────────────────────
      Dimensions cb = parent->dimensions;
      cb.content.height = 0;
      child->layout(cb);

      float w = child->dimensions.margin_box().width;
      float h = child->dimensions.margin_box().height;

      // Wrap if needed
      if (cursor_x + w > max_x + 0.5f && cursor_x > line_x + 0.5f) {
        flush_line();
      }

      // Treat inline element as a single opaque fragment
      // Ascent = full height (top-aligned within line), descent = 0
      float lh = css_line_height(child, get_font_size(child->style_node));
      InlineFragment f;
      f.box         = child.get();
      f.is_text     = false;
      f.x           = cursor_x + child->dimensions.margin.left;
      f.width       = w;
      f.ascent      = h;   // entire height above baseline
      f.descent     = 0.f;
      f.line_height = std::max(lh, h);

      // Park at (0,0); commit_line will set absolute y
      child->dimensions.content.x = 0;
      child->dimensions.content.y = 0;
      current_line.frags.push_back(f);
      cursor_x += w;
    }
  }

  flush_line();

  parent->dimensions.content.height =
      cursor_y - parent->dimensions.content.y;
}

/* Layout children */

void LayoutBox::layout_block_children() {

  float cursor_y = dimensions.content.y;

  // Determine if we have any block children
  bool has_block_child = false;
  bool any_content = false;
  for (auto &child : children) {
    if (!child)
      continue;
    // Whitespace-only text nodes between block elements don't count as content
    if (child->box_type == BoxType::InlineNode && child->style_node &&
        child->style_node->node &&
        child->style_node->node->type == NodeType::Text) {
      const std::string &txt = child->style_node->node->data;
      bool only_ws = true;
      for (char c : txt) {
        if (c != ' ' && c != '\t' && c != '\r' && c != '\n') {
          only_ws = false;
          break;
        }
      }
      if (only_ws)
        continue;
    }
    any_content = true;
    if (child->box_type != BoxType::InlineNode) {
      has_block_child = true;
      break;
    }
  }

  // Pure inline container — use inline flow
  if (!has_block_child && any_content) {
    layout_inline_flow(this);
    return;
  }

  // Mixed or pure block: process children in order.
  // Consecutive inline children are grouped into a temporary anonymous block
  // and laid out together via layout_inline_flow so they flow horizontally.
  std::vector<std::shared_ptr<LayoutBox>> inline_run;

  auto flush_inline_run = [&]() {
    if (inline_run.empty())
      return;

    // Lay out each inline child then position them in a horizontal run
    float cx = dimensions.content.x;
    float cy = cursor_y;
    float max_x = dimensions.content.x + dimensions.content.width;
    float row_h = 16.0f;

    for (size_t ri = 0; ri < inline_run.size(); ++ri) {
      std::shared_ptr<LayoutBox> &ic = inline_run[ri];
      if (!ic)
        continue;

      // <br> forces a line break
      bool is_br = ic->style_node && ic->style_node->node &&
                   ic->style_node->node->type == NodeType::Element &&
                   ic->style_node->node->data == "br";
      if (is_br) {
        cx = dimensions.content.x;
        cy += row_h;
        row_h = 16.0f;
        continue;
      }

      Dimensions ic_cb = dimensions;
      ic_cb.content.height = 0;
      ic->layout(ic_cb);

      float w = ic->dimensions.margin_box().width;
      float h = ic->dimensions.margin_box().height;
      if (h < 1)
        h = 16.0f;

      if (cx + w > max_x &&
          cx > dimensions.content.x + dimensions.padding.left) {
        cx = dimensions.content.x;
        cy += row_h;
        row_h = h;
      }
      float old_x = ic->dimensions.content.x;
      float old_y = ic->dimensions.content.y;
      ic->dimensions.content.x = cx + ic->dimensions.margin.left;
      ic->dimensions.content.y = cy + ic->dimensions.margin.top;
      float ddx = ic->dimensions.content.x - old_x;
      float ddy = ic->dimensions.content.y - old_y;
      if (ddx != 0.0f || ddy != 0.0f)
        offset_children(ic.get(), ddx, ddy);
      row_h = std::max(row_h, h);
      cx += w;
    }
    cursor_y = cy + row_h;
    inline_run.clear();
  };

  for (auto &child : children) {
    if (!child)
      continue;

    // Skip whitespace-only text nodes between block elements — they're HTML
    // formatting
    if (child->box_type == BoxType::InlineNode && child->style_node &&
        child->style_node->node &&
        child->style_node->node->type == NodeType::Text) {
      const std::string &txt = child->style_node->node->data;
      bool only_ws = true;
      for (char c : txt) {
        if (c != ' ' && c != '\t' && c != '\r' && c != '\n') {
          only_ws = false;
          break;
        }
      }
      if (only_ws)
        continue; // skip — don't add to inline_run
    }

    if (child->box_type == BoxType::InlineNode) {
      inline_run.push_back(child);
    } else {
      // Flush pending inline run first
      flush_inline_run();

      Dimensions child_cb = dimensions;
      child_cb.content.height = cursor_y - dimensions.content.y;
      child->layout(child_cb);

      // position:absolute and position:fixed elements are out of flow —
      // they don't advance the block cursor
      std::string child_pos =
          child->style_node ? child->style_node->value("position") : "static";
      if (child_pos != "absolute" && child_pos != "fixed") {
        cursor_y = child->dimensions.margin_box().y +
                   child->dimensions.margin_box().height;
      }
    }
  }
  flush_inline_run();

  dimensions.content.height = cursor_y - dimensions.content.y;
}

void LayoutBox::layout_inline_children() {
  auto &fm  = FontMetrics::get_instance();
  int   pfs = get_font_size(style_node);
  bool  bold = get_font_weight_bold(style_node);
  float lh  = css_line_height(this, pfs);
  // Ascent/descent for this element's own font
  float ascent  = (float)pfs * 0.8f;
  float descent = lh - ascent;

  // This box lays out its children relative to its own content origin (0,0).
  // The parent's flush_inline_run (or commit_line) will later shift everything
  // to absolute page coordinates via offset_children().

  float cx     = 0.f;  // cursor x relative to content origin
  float max_cx = 0.f;
  float row_h  = lh;

  float avail_w = dimensions.content.width > 0
                  ? dimensions.content.width
                  : 9999.f; // no wrapping inside inline elements

  for (auto &child : children) {
    if (!child) continue;

    bool is_text = child->style_node && child->style_node->node &&
                   child->style_node->node->type == NodeType::Text;

    if (is_text) {
      int   fs   = get_font_size(child->style_node);
      bool  cbold= get_font_weight_bold(child->style_node);
      float clh  = css_line_height(child, fs);
      float casc = (float)fs * 0.8f;

      std::string collapsed = collapse_whitespace(child->style_node->node->data);
      if (collapsed.empty()) {
        child->dimensions.content = {cx, 0.f, 0.f, (float)fs};
        continue;
      }

      auto metrics = fm.measure_text(collapsed, fs, cbold);
      child->dimensions.content.x      = cx;
      child->dimensions.content.y      = 0.f; // y set by commit_line
      child->dimensions.content.width  = metrics.width;
      child->dimensions.content.height = (float)fs;

      row_h = std::max(row_h, clh);
      cx   += metrics.width;
    } else {
      // Nested inline element
      float child_lh = css_line_height(child, get_font_size(child->style_node));
      child->dimensions.content.x = cx + child->dimensions.padding.left;
      child->dimensions.content.y = child->dimensions.padding.top;
      child->layout_inline_children();

      float w = child->dimensions.content.width
              + child->dimensions.padding.left
              + child->dimensions.padding.right;
      float h = child->dimensions.content.height
              + child->dimensions.padding.top
              + child->dimensions.padding.bottom;
      if (h < 1.f) h = child_lh;

      row_h = std::max(row_h, h);
      cx   += w;
    }
    max_cx = std::max(max_cx, cx);
  }

  // Shrink-wrap: content.width = max child extent, height = line height
  dimensions.content.width  = max_cx > 0.f ? max_cx : 0.f;
  dimensions.content.height = row_h;
}

// After flush_inline_run sets a box's absolute position,
// shift all its children by (dx, dy) so they are absolutely positioned too.
static void offset_children(LayoutBox *box, float dx, float dy) {
  if (!box)
    return;
  for (auto &child : box->children) {
    if (!child)
      continue;
    child->dimensions.content.x += dx;
    child->dimensions.content.y += dy;
    offset_children(child.get(), dx, dy);
  }
}

/* Height */

void LayoutBox::calculate_block_height() {
  auto &style = style_node->specified_values;
  extern int g_viewport_height;
  float vp_h = g_viewport_height > 0 ? (float)g_viewport_height : 768.0f;

  // If an explicit height was set in CSS, use it
  if (style.count("height")) {
    const std::string &hv = style.at("height");
    float h = 0;
    if (!hv.empty() && hv.back() == '%') {
      // Percentage height: resolve against viewport height as fallback
      // (containing block height is often 0 for top-level elements)
      float pct = 0;
      try {
        pct = std::stof(hv.substr(0, hv.length() - 1));
      } catch (...) {
      }
      h = vp_h * pct / 100.0f;
    } else {
      h = parse_px(hv, 0);
    }
    if (h > 0) {
      dimensions.content.height = h;
      return;
    }
  }

  // Apply min-height (also resolve % against viewport)
  if (style.count("min-height")) {
    const std::string &mv = style.at("min-height");
    float minh = 0;
    if (!mv.empty() && mv.back() == '%') {
      float pct = 0;
      try {
        pct = std::stof(mv.substr(0, mv.length() - 1));
      } catch (...) {
      }
      minh = vp_h * pct / 100.0f;
    } else {
      minh = parse_px(mv, 0);
    }
    if (dimensions.content.height < minh)
      dimensions.content.height = minh;
  }

  // Don't override height that was already computed by layout_block_children
  // Only apply a minimum if we have actual content but zero height
  if (dimensions.content.height == 0 && !children.empty()) {
    dimensions.content.height = 20;
  }
}

/* Layout tree builder */

std::shared_ptr<LayoutBox>
build_layout_tree(std::shared_ptr<StyledNode> style_node) {
  if (!style_node)
    return nullptr;

  // Skip root-level text nodes (whitespace before <html>)
  if (style_node->node && style_node->node->type == NodeType::Text &&
      style_node->children.size() == 1) {
    return build_layout_tree(style_node->children[0]);
  }

  // 🚀 Skip hidden nodes
  if (is_display_none(style_node))
    return nullptr;

  BoxType type = BoxType::BlockNode;

  // Text nodes are always inline
  if (style_node->node && style_node->node->type == NodeType::Text) {
    type = BoxType::InlineNode;
  } else if (!style_node->node || style_node->node->type != NodeType::Element ||
             style_node->node->data.empty()) {
    // Document wrapper or node with no element tag: always block
    type = BoxType::BlockNode;
  } else {
    std::string tag = style_node->node->data;
    std::string display = style_node->value("display");

    // Skip hidden-by-default elements
    if (tag == "script" || tag == "style" || tag == "meta" || tag == "link" ||
        tag == "head" || tag == "title" || tag == "template") {
      return nullptr;
    }
    // <br>: forced line break
    if (tag == "br") {
      auto br_box =
          std::make_shared<LayoutBox>(BoxType::InlineNode, style_node);
      br_box->dimensions.content.width = 0;
      br_box->dimensions.content.height = 20;
      return br_box;
    }

    if (display == "flex") {
      type = BoxType::FlexContainer;
    } else if (display == "grid") {
      type = BoxType::GridContainer;
    } else if (display == "inline" || display == "inline-block" ||
               display == "inline-flex") {
      type = BoxType::InlineNode;
    } else if (display == "block") {
      type = BoxType::BlockNode;
    } else if (is_inline_tag(tag)) {
      type = BoxType::InlineNode;
    }
    // else: type stays BlockNode (default for unknown/empty display)
  }

  auto root = std::make_shared<LayoutBox>(type, style_node);

  for (auto &child : style_node->children) {
    auto c = build_layout_tree(child);
    if (c)
      root->children.push_back(c);
  }

  return root;
}

/* Debug */

void print_layout_tree(const std::shared_ptr<LayoutBox> &root, int indent) {
  if (!root || indent > 12)
    return; // max depth 6 levels

  std::string pad(indent, ' ');
  std::string type_str = "BLOCK";
  if (root->box_type == BoxType::InlineNode)
    type_str = "INLINE";
  else if (root->box_type == BoxType::FlexContainer)
    type_str = "FLEX";
  else if (root->box_type == BoxType::GridContainer)
    type_str = "GRID";

  std::string tag = "?";
  if (root->style_node && root->style_node->node) {
    if (root->style_node->node->type == NodeType::Text)
      tag = "TEXT[" + root->style_node->node->data.substr(0, 15) + "]";
    else
      tag = root->style_node->node->data;
  }

  fprintf(stderr, "%s%s<%s> x=%.0f y=%.0f w=%.0f h=%.0f\n", pad.c_str(),
          type_str.c_str(), tag.c_str(), root->dimensions.content.x,
          root->dimensions.content.y, root->dimensions.content.width,
          root->dimensions.content.height);

  for (auto &c : root->children)
    print_layout_tree(c, indent + 2);
}
// DEBUG: dump layout tree to stderr
void dump_layout(LayoutBox *box, int depth = 0) {
  if (!box)
    return;
  std::string indent(depth * 2, ' ');
  std::string tag = "?";
  if (box->style_node && box->style_node->node) {
    if (box->style_node->node->type == NodeType::Text)
      tag = "TEXT[" + box->style_node->node->data.substr(0, 20) + "]";
    else
      tag = box->style_node->node->data;
  }
  fprintf(stderr, "%s%s (%.0f,%.0f) w=%.0f h=%.0f type=%d\n", indent.c_str(),
          tag.c_str(), box->dimensions.content.x, box->dimensions.content.y,
          box->dimensions.content.width, box->dimensions.content.height,
          (int)box->box_type);
  if (depth < 4) {
    for (auto &c : box->children)
      dump_layout(c.get(), depth + 1);
  }
}
