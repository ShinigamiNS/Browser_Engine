#include "browser_ui.h"
#include "css_parser.h"
#include "dom_builder.h"
#include "lexbor_adapter.h"
#include "html_parser.h"
#include "quickjs_adapter.h"
#include "layout.h"
#include "net.h"
#include "paint.h"
#include "style.h"
#include "utils.h"
#include <cstdint>
#include <iostream>
#include <map>
#include <string>
#include <vector>
#include <windows.h>

// GDI+ for image decoding
#include <objidl.h>
#define GDIPVER 0x0110
#include <gdiplus.h>
// Link gdiplus in the Makefile/build system instead of pragma
// #pragma comment(lib, "gdiplus.lib")

// ============================================================================
//  Global State
// ============================================================================

bool running = true;
bool app_initialized = false; // Guard against early WM_PAINT/WM_SIZE
void *buffer_memory = nullptr;
int buffer_width = 800;
int buffer_height = 600;
BITMAPINFO bitmap_info;

// Real viewport content height (excluding chrome) — used by fixed positioning
int g_viewport_height = 600;
int g_viewport_width = 800;

// ============================================================================
//  Image Cache (URL -> decoded HBITMAP, stored as 32bpp DIB pixel data)
// ============================================================================
struct CachedImage {
  std::vector<uint32_t> pixels; // BGRA pixels (GDI DIB format 0x00RRGGBB)
  int width = 0;
  int height = 0;
};
std::map<std::string, CachedImage> g_image_cache;
CRITICAL_SECTION
g_image_cache_cs; // Windows CRITICAL_SECTION instead of std::mutex
ULONG_PTR g_gdip_token = 0;
HWND g_hwnd = NULL; // set in WinMain

// Resolve a relative/protocol-relative URL against a base page URL
static std::string resolve_url(const std::string &src,
                               const std::string &page_url) {
  if (src.empty())
    return "";
  if (src.substr(0, 8) == "https://" || src.substr(0, 7) == "http://")
    return src;
  if (src.substr(0, 2) == "//")
    return "https:" + src;
  if (src[0] == '/') {
    // find origin from page_url
    size_t scheme_end = page_url.find("://");
    if (scheme_end == std::string::npos)
      return "";
    size_t host_end = page_url.find('/', scheme_end + 3);
    std::string origin = (host_end == std::string::npos)
                             ? page_url
                             : page_url.substr(0, host_end);
    return "https://" + origin.substr(origin.find("://") + 3) + src;
  }
  // relative path — append to page dir
  size_t last_slash = page_url.rfind('/');
  if (last_slash == std::string::npos)
    return src;
  return page_url.substr(0, last_slash + 1) + src;
}

// Simple read-only IStream over a byte buffer — avoids ole32 dependency
struct MemStream : public IStream {
  const uint8_t *data;
  SIZE_T size;
  SIZE_T pos;
  LONG ref_count;

  MemStream(const void *d, SIZE_T s)
      : data((const uint8_t *)d), size(s), pos(0), ref_count(1) {}

  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID, void **) {
    return E_NOINTERFACE;
  }
  ULONG STDMETHODCALLTYPE AddRef() { return ++ref_count; }
  ULONG STDMETHODCALLTYPE Release() {
    if (--ref_count == 0) {
      delete this;
      return 0;
    }
    return ref_count;
  }

  HRESULT STDMETHODCALLTYPE Read(void *pv, ULONG cb, ULONG *pcbRead) {
    ULONG avail = (ULONG)(size - pos);
    ULONG n = cb < avail ? cb : avail;
    memcpy(pv, data + pos, n);
    pos += n;
    if (pcbRead)
      *pcbRead = n;
    return (n == cb) ? S_OK : S_FALSE;
  }
  HRESULT STDMETHODCALLTYPE Write(const void *, ULONG, ULONG *) {
    return E_NOTIMPL;
  }
  HRESULT STDMETHODCALLTYPE Seek(LARGE_INTEGER dlibMove, DWORD dwOrigin,
                                 ULARGE_INTEGER *plibNewPos) {
    LONGLONG newpos;
    if (dwOrigin == STREAM_SEEK_SET)
      newpos = dlibMove.QuadPart;
    else if (dwOrigin == STREAM_SEEK_CUR)
      newpos = (LONGLONG)pos + dlibMove.QuadPart;
    else if (dwOrigin == STREAM_SEEK_END)
      newpos = (LONGLONG)size + dlibMove.QuadPart;
    else
      return STG_E_INVALIDFUNCTION;
    if (newpos < 0 || (SIZE_T)newpos > size)
      return STG_E_INVALIDFUNCTION;
    pos = (SIZE_T)newpos;
    if (plibNewPos)
      plibNewPos->QuadPart = pos;
    return S_OK;
  }
  HRESULT STDMETHODCALLTYPE SetSize(ULARGE_INTEGER) { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CopyTo(IStream *, ULARGE_INTEGER, ULARGE_INTEGER *,
                                   ULARGE_INTEGER *) {
    return E_NOTIMPL;
  }
  HRESULT STDMETHODCALLTYPE Commit(DWORD) { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Revert() { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE LockRegion(ULARGE_INTEGER, ULARGE_INTEGER, DWORD) {
    return E_NOTIMPL;
  }
  HRESULT STDMETHODCALLTYPE UnlockRegion(ULARGE_INTEGER, ULARGE_INTEGER,
                                         DWORD) {
    return E_NOTIMPL;
  }
  HRESULT STDMETHODCALLTYPE Stat(STATSTG *s, DWORD) {
    if (s) {
      memset(s, 0, sizeof(*s));
      s->cbSize.QuadPart = size;
    }
    return S_OK;
  }
  HRESULT STDMETHODCALLTYPE Clone(IStream **) { return E_NOTIMPL; }
};

// Decode image bytes (PNG/JPEG/GIF/etc) using GDI+ into a CachedImage
static bool decode_image_bytes(const std::string &bytes, CachedImage &out) {
  if (bytes.empty())
    return false;

  IStream *stream = new MemStream(bytes.data(), bytes.size());

  Gdiplus::Bitmap *bmp = Gdiplus::Bitmap::FromStream(stream);
  stream->Release();

  if (!bmp || bmp->GetLastStatus() != Gdiplus::Ok) {
    delete bmp;
    return false;
  }

  int w = (int)bmp->GetWidth();
  int h = (int)bmp->GetHeight();
  if (w <= 0 || h <= 0 || w > 4096 || h > 4096) {
    delete bmp;
    return false;
  }

  out.width = w;
  out.height = h;
  out.pixels.resize(w * h);

  Gdiplus::Rect rc(0, 0, w, h);
  Gdiplus::BitmapData data;
  if (bmp->LockBits(&rc, Gdiplus::ImageLockModeRead, PixelFormat32bppARGB,
                    &data) == Gdiplus::Ok) {
    uint8_t *src_row = (uint8_t *)data.Scan0;
    for (int y = 0; y < h; y++) {
      uint32_t *src = (uint32_t *)(src_row + y * data.Stride);
      uint32_t *dst = out.pixels.data() + y * w;
      for (int x = 0; x < w; x++) {
        uint32_t px = src[x];
        uint8_t a = (px >> 24) & 0xFF;
        uint8_t r = (px >> 16) & 0xFF;
        uint8_t g = (px >> 8) & 0xFF;
        uint8_t b = px & 0xFF;
        // Composite over white for semi-transparent pixels
        r = (uint8_t)(r + (255 - a) * (255 - r) / 255);
        g = (uint8_t)(g + (255 - a) * (255 - g) / 255);
        b = (uint8_t)(b + (255 - a) * (255 - b) / 255);
        dst[x] = ((uint32_t)r << 16) | ((uint32_t)g << 8) | b;
      }
    }
    bmp->UnlockBits(&data);
  }
  delete bmp;
  return !out.pixels.empty();
}

// Collect all img src URLs from a layout tree
static void collect_img_urls(const std::shared_ptr<LayoutBox> &box,
                             const std::string &page_url,
                             std::vector<std::string> &out) {
  if (!box)
    return;
  if (box->style_node && box->style_node->node &&
      box->style_node->node->type == NodeType::Element &&
      box->style_node->node->data == "img") {
    auto &attrs = box->style_node->node->attributes;
    auto it = attrs.find("src");
    if (it != attrs.end() && !it->second.empty()) {
      std::string url = resolve_url(it->second, page_url);
      if (!url.empty() && url.substr(0, 8) == "https://")
        out.push_back(url);
    }
  }
  for (auto &child : box->children)
    collect_img_urls(child, page_url, out);
}

// Thread param struct for image fetching
struct ImgFetchParams {
  std::vector<std::string> urls;
  HWND hwnd;
};

// Fetch and decode all images; post WM_USER+1 to trigger repaint when done
static DWORD WINAPI fetch_images_thread(LPVOID param) {
  ImgFetchParams *p = (ImgFetchParams *)param;
  std::vector<std::string> urls = p->urls;
  HWND hwnd = p->hwnd;
  delete p;

  for (size_t i = 0; i < urls.size(); ++i) {
    const std::string &url = urls[i];
    {
      EnterCriticalSection(&g_image_cache_cs);
      bool cached = (g_image_cache.count(url) > 0);
      LeaveCriticalSection(&g_image_cache_cs);
      if (cached)
        continue;
    }
    std::string bytes = fetch_https(url);
    CachedImage img;
    if (decode_image_bytes(bytes, img)) {
      EnterCriticalSection(&g_image_cache_cs);
      g_image_cache[url] = img;
      LeaveCriticalSection(&g_image_cache_cs);
    } else {
      EnterCriticalSection(&g_image_cache_cs);
      g_image_cache[url] = CachedImage();
      LeaveCriticalSection(&g_image_cache_cs);
    }
    PostMessage(hwnd, WM_USER + 1, 0, 0);
  }
  return 0;
}

std::shared_ptr<LayoutBox> global_layout_root = nullptr;
static std::shared_ptr<Node> g_dom_root;
static Stylesheet g_main_stylesheet;
static Stylesheet g_hover_stylesheet;
static Stylesheet g_focus_stylesheet;
static QJSEngine* g_qjs_engine = nullptr;
static Node* g_hovered_node = nullptr;
static Node* g_focused_node = nullptr;
std::shared_ptr<LayoutBox> focused_box = nullptr;
// js::Environment removed - using QuickJS (qjs_engine) instead
DisplayList master_display_list;
std::string g_current_page_url;

// The UI backend instance
BrowserUI browser_ui;

// Scroll state
int scroll_y = 0;
static const int SCROLL_STEP = 40;
static const int SCROLLBAR_WIDTH = 12;
bool is_scrolling = false;
int scroll_drag_start_y = 0;
int scroll_start_val = 0;
float scroll_max = 0;

// ============================================================================
//  Page Loading Pipeline
// ============================================================================

void load_page(const std::string &raw_url) {
  try {
    std::string html;
        std::string url = raw_url;

    browser_ui.set_loading(true);
    browser_ui.set_status("Loading...");

    if (url.empty()) {
      // Home page — simple HTML without inline style attributes
      // (our parser doesn't support inline style= attributes)
      html = "<html><head><title>Scratch Browser</title>"
             "<style>"
             "body { background-color: #1e2026; color: #e0e4f0; }"
             ".hero { padding: 60px; }"
             ".title { color: #5082ff; font-size: 36px; }"
             ".subtitle { font-size: 18px; color: #8890a0; }"
             ".footer { font-size: 14px; color: #5a5e6e; }"
             "</style></head>"
             "<body><div class=\"hero\">"
             "<h1 class=\"title\">Scratch Browser</h1>"
             "<p class=\"subtitle\">Type a URL in the address bar above "
             "and press Enter or click Go to navigate.</p>"
             "<br/>"
             "<p class=\"footer\">Built from scratch with custom HTML parser, "
             "CSS engine, layout engine, and paint system.</p>"
             "</div></body></html>";
    } else {
      // Try local file first
      html = read_file(url);
      if (html.empty()) {
        if (url.length() < 4 ||
            (url.substr(0, 8) != "https://" && url.substr(0, 7) != "http://")) {
          url = "https://" + url;
        }
        html = fetch_https(url);
      }
      if (html.empty()) {
        html = "<html><head><title>Error</title>"
               "<style>"
               "body { background-color: #1e2026; color: #e0e4f0; }"
               ".err { padding: 60px; }"
               "h1 { color: #e84848; }"
               "p { font-size: 16px; color: #8890a0; }"
               "</style></head>"
               "<body><div class=\"err\">"
               "<h1>Network Error</h1>"
               "<p>Could not load the page.</p>"
               "</div></body></html>";
      }
    }

    // Default CSS — UA stylesheet so inline elements aren't treated as block
    std::string css =
        "head,script,style,meta,link,title{display:none}\n"
        // Body default margin (browser default is 8px)
        "body{margin:8px}\n"
        // Inline elements
        "a,span,b,strong,em,i,u,small,abbr,cite,code,sub,sup,label,"
        "button,input,select,textarea,img{"
        "display:inline}\n"
        // Block elements that should stack
        "div,p,h1,h2,h3,h4,h5,h6,ul,ol,li,section,article,header,"
        "footer,nav,main,aside,form,table,tr,thead,tbody,tfoot,caption,"
        "blockquote,pre,figure,figcaption,address,hr,br{"
        "display:block}\n"
        // Heading font sizes
        "h1{font-size:32px;font-weight:bold}\n"
        "h2{font-size:24px;font-weight:bold}\n"
        "h3{font-size:20px;font-weight:bold}\n"
        "h4{font-size:16px;font-weight:bold}\n"
        // Link color
        "a{color:#0000EE}\n" +
        read_file("test.css");

    // Parse HTML with Lexbor (HTML5 spec-compliant)
    std::cerr << "Parsing HTML (" << html.size() / 1024 << " KB)...\n";
    auto root = lexbor_parse_to_dom(html);

    // Extract CSS from parsed DOM (Lexbor preserves style tag content correctly)
    {
      std::string page_css = lexbor_extract_css(root);
      static const size_t MAX_CSS_SIZE = 512 * 1024;
      if (page_css.size() > MAX_CSS_SIZE) page_css.resize(MAX_CSS_SIZE);
      css += page_css;
    }

    html.clear();
    html.shrink_to_fit();

    if (!root) root = ElementNode("html");

    // Fetch external stylesheets <link rel="stylesheet">
    {
      static const int MAX_SHEETS = 8;
      int sheets_fetched = 0;
      std::function<void(std::shared_ptr<Node>)> collect_links;
      collect_links = [&](std::shared_ptr<Node> node) {
        if (!node || sheets_fetched >= MAX_SHEETS) return;
        if (node->type == NodeType::Element && node->data == "link") {
          auto& attrs = node->attributes;
          auto rel_it = attrs.find("rel");
          if (rel_it == attrs.end()) { for (auto& c : node->children) collect_links(c); return; }
          std::string rel = rel_it->second;
          std::transform(rel.begin(), rel.end(), rel.begin(), ::tolower);
          if (rel.find("stylesheet") == std::string::npos) return;
          auto href_it = attrs.find("href");
          if (href_it == attrs.end() || href_it->second.empty()) return;
          if (href_it->second.substr(0,5) == "data:") return;
          auto media_it = attrs.find("media");
          if (media_it != attrs.end()) {
            std::string media = media_it->second;
            std::transform(media.begin(), media.end(), media.begin(), ::tolower);
            if (media == "print") return;
          }
          std::string sheet_url = resolve_url(href_it->second, url);
          if (sheet_url.empty()) return;
          std::cerr << "Fetching CSS: " << sheet_url << "\n";
          std::string sheet = fetch_https(sheet_url);
          if (!sheet.empty()) {
            if (sheet.size() > 512*1024) sheet.resize(512*1024);
            css += "\n" + sheet + "\n";
            sheets_fetched++;
          }
        }
        for (auto& c : node->children) collect_links(c);
      };
      collect_links(root);
    }

    if (!root) {
      root = ElementNode("html");
    }

    // Count total DOM nodes
    std::function<int(std::shared_ptr<Node>)> count_nodes;
    count_nodes = [&](std::shared_ptr<Node> node) -> int {
      if (!node)
        return 0;
      int c = 1;
      for (auto &child : node->children) {
        c += count_nodes(child);
        if (c > 50000)
          break;
      }
      return c;
    };
    int total_nodes = count_nodes(root);
    std::cerr << "DOM nodes: " << total_nodes << "\n";

    // Run JavaScript with QuickJS (full ES2020)
    std::cerr << "Running scripts...\n";
    if (g_qjs_engine) { qjs_destroy(g_qjs_engine); g_qjs_engine = nullptr; }
    g_qjs_engine = qjs_create(root);
    qjs_run_scripts(g_qjs_engine, root);
    qjs_call_global(g_qjs_engine, "onload");

    std::cerr << "Total CSS: " << css.size() / 1024 << " KB\n";

    // Extract :hover/:focus rules before preprocessing strips them
    std::string hover_css, focus_css;
    {
      size_t i = 0;
      while (i < css.size()) {
        // skip comments
        if (css[i]=='/' && i+1<css.size() && css[i+1]=='*') {
          i+=2; while(i+1<css.size()&&!(css[i]=='*'&&css[i+1]=='/'))i++; if(i+1<css.size())i+=2; continue;
        }
        if (css[i]=='@') {
          while(i<css.size()&&css[i]!='{' &&css[i]!=';')i++;
          if(i<css.size()&&css[i]==';'){i++;continue;}
          if(i<css.size()&&css[i]=='{'){int d=1;i++;while(i<css.size()&&d>0){if(css[i]=='{')d++;else if(css[i]=='}')d--;i++;}continue;}
          continue;
        }
        if (css[i]=='{') {
          size_t sel_end = i;
          // find selector start by going back to last } or start
          size_t sel_start = css.rfind('}', sel_end > 0 ? sel_end-1 : 0);
          sel_start = (sel_start==std::string::npos) ? 0 : sel_start+1;
          std::string selector = css.substr(sel_start, sel_end-sel_start);
          // find matching }
          int d=1; size_t j=i+1;
          while(j<css.size()&&d>0){if(css[j]=='{')d++;else if(css[j]=='}')d--;j++;}
          std::string body = css.substr(i, j-i);
          auto strip_ps=[](const std::string& s,const std::string& ps){
            std::string o=s; size_t p;
            while((p=o.find(ps))!=std::string::npos){size_t e=p+ps.size();o.erase(p,e-p);}
            return o;
          };
          if (selector.find(":hover")!=std::string::npos) {
            std::string cs=strip_ps(selector,":hover");
            if(!cs.empty()&&cs.find_first_not_of(" \t\n\r,")!=std::string::npos)
              hover_css+=cs+body+"\n";
          }
          if (selector.find(":focus")!=std::string::npos) {
            std::string cs=strip_ps(selector,":focus");
            if(!cs.empty()&&cs.find_first_not_of(" \t\n\r,")!=std::string::npos)
              focus_css+=cs+body+"\n";
          }
          i=j; continue;
        }
        i++;
      }
    }

        // Preprocess CSS: strip pseudo-classes, attribute selectors, and @-rules
    // that our CSS parser cannot handle (it will infinite-loop on ':'
    // selectors). We track string literals and comments to avoid false
    // positives.
    {
      std::string cleaned;
      cleaned.reserve(css.size());
      size_t i = 0;
      int brace_depth = 0;

      while (i < css.size()) {
        char c = css[i];

        // Skip block comments /* ... */ at any depth
        if (c == '/' && i + 1 < css.size() && css[i + 1] == '*') {
          i += 2;
          while (i + 1 < css.size() && !(css[i] == '*' && css[i + 1] == '/'))
            i++;
          if (i + 1 < css.size())
            i += 2;
          continue;
        }

        // Inside a rule body: pass through verbatim, tracking strings and
        // braces
        if (brace_depth > 0) {
          // Track string literals so '}' inside a string doesn't affect depth
          if (c == '"' || c == '\'') {
            char q = c;
            cleaned += c;
            i++;
            while (i < css.size() && css[i] != q) {
              if (css[i] == '\\') {
                cleaned += css[i++];
              } // escape
              if (i < css.size()) {
                cleaned += css[i++];
              }
            }
            if (i < css.size()) {
              cleaned += css[i++];
            } // closing quote
            continue;
          }
          if (c == '{') {
            brace_depth++;
            cleaned += c;
            i++;
            continue;
          }
          if (c == '}') {
            brace_depth--;
            cleaned += c;
            i++;
            continue;
          }
          cleaned += c;
          i++;
          continue;
        }

        // Selector context (brace_depth == 0)

        // Opening brace: enter rule body
        if (c == '{') {
          brace_depth++;
          cleaned += c;
          i++;
          continue;
        }
        // Stray closing brace: skip
        if (c == '}') {
          i++;
          continue;
        }

        // Skip ALL @-rules (parser handles some but not all; safest to strip
        // all)
        if (c == '@') {
          while (i < css.size() && css[i] != '{' && css[i] != ';')
            i++;
          if (i < css.size() && css[i] == ';') {
            i++;
            continue;
          }
          if (i < css.size() && css[i] == '{') {
            int depth = 1;
            i++;
            while (i < css.size() && depth > 0) {
              if (css[i] == '{')
                depth++;
              else if (css[i] == '}')
                depth--;
              i++;
            }
          }
          continue;
        }

        // Strip pseudo-classes/elements :foo ::foo :not(...)
        if (c == ':') {
          i++;
          if (i < css.size() && css[i] == ':')
            i++;
          while (i < css.size() && (isalnum((unsigned char)css[i]) ||
                                    css[i] == '-' || css[i] == '_'))
            i++;
          if (i < css.size() && css[i] == '(') {
            int depth = 1;
            i++;
            while (i < css.size() && depth > 0) {
              if (css[i] == '(')
                depth++;
              else if (css[i] == ')')
                depth--;
              i++;
            }
          }
          continue;
        }

        // Strip attribute selectors [...]
        if (c == '[') {
          int depth = 1;
          i++;
          while (i < css.size() && depth > 0) {
            if (css[i] == '[')
              depth++;
            else if (css[i] == ']')
              depth--;
            i++;
          }
          continue;
        }

        // Replace '*' wildcard — the CSS parser breaks on '*' without consuming
        // it, causing an infinite loop. Expand to common elements instead so
        // rules like "* { box-sizing:border-box }" still apply broadly.
        if (c == '*') {
          cleaned += "html,body,div,span,p,a,ul,ol,li,"
                     "h1,h2,h3,h4,h5,h6,table,tr,td,th,"
                     "input,button,select,textarea,form,"
                     "section,article,header,footer,nav,main,aside";
          i++;
          continue;
        }

        cleaned += c;
        i++;
      }
      css = std::move(cleaned);
    }

    // Hard limit: if CSS is still very large after preprocessing, truncate.
    // The CSS parser can handle ~500 rules comfortably; beyond that we get
    // diminishing returns for our simple style engine anyway.
    static const size_t CSS_PARSE_LIMIT = 128 * 1024; // 128KB
    if (css.size() > CSS_PARSE_LIMIT) {
      // Truncate at a rule boundary (find last '}' before the limit)
      size_t cut = CSS_PARSE_LIMIT;
      while (cut > 0 && css[cut] != '}')
        cut--;
      if (cut > 0)
        css.resize(cut + 1);
    }
    std::cerr << "CSS after preprocessing: " << css.size() / 1024 << " KB\n";
    // Dump first 3KB of preprocessed CSS to inspect rules
    {
      FILE *f = fopen("css_dump.txt", "w");
      if (f) {
        fwrite(css.c_str(), 1, std::min(css.size(), (size_t)3000), f);
        // Also search for specific class names we care about
        fprintf(f, "\n\n--- Rules containing 'o3j99' ---\n");
        size_t p = 0;
        while ((p = css.find("o3j99", p)) != std::string::npos) {
          size_t start = css.rfind('\n', p);
          if (start == std::string::npos)
            start = 0;
          else
            start++;
          size_t end = css.find('}', p);
          if (end == std::string::npos)
            end = p + 200;
          else
            end++;
          fprintf(f, "%s\n", css.substr(start, end - start).c_str());
          p = end;
        }
        fprintf(f, "\n--- Rules containing 'L3eUgb' ---\n");
        p = 0;
        while ((p = css.find("L3eUgb", p)) != std::string::npos) {
          size_t start = css.rfind('\n', p);
          if (start == std::string::npos)
            start = 0;
          else
            start++;
          size_t end = css.find('}', p);
          if (end == std::string::npos)
            end = p + 200;
          else
            end++;
          fprintf(f, "%s\n", css.substr(start, end - start).c_str());
          p = end;
        }
        fclose(f);
      }
    }

    // CSS parsing and style tree construction
    std::cerr << "Parsing CSS...\n";
    CSSParser css_parser(css);
    auto stylesheet = css_parser.parse_stylesheet();
    // Free raw CSS text
    css.clear();
    css.shrink_to_fit();

    std::cerr << "CSS rules: " << stylesheet.rules.size() << "\n";

    // Parse hover/focus stylesheets
    if (!hover_css.empty()) {
      CSSParser hp(hover_css); g_hover_stylesheet = hp.parse_stylesheet();
      std::cerr << "Hover rules: " << g_hover_stylesheet.rules.size() << "\n";
    }
    if (!focus_css.empty()) {
      CSSParser fp(focus_css); g_focus_stylesheet = fp.parse_stylesheet();
    }

    std::cerr << "DOM ready, building style tree...\n";

    g_dom_root = root;
    g_main_stylesheet = stylesheet;
    auto styleTreeRoot = build_style_tree(root, stylesheet,
        g_hover_stylesheet.rules.empty() ? nullptr : &g_hover_stylesheet,
        g_focus_stylesheet.rules.empty() ? nullptr : &g_focus_stylesheet);

    // Layout
    global_layout_root = build_layout_tree(styleTreeRoot);
    if (global_layout_root) {
      Dimensions viewport;
      int cw = browser_ui.content_width();
      int ch = browser_ui.content_height();
      if (cw < 1)
        cw = 800;
      if (ch < 1)
        ch = 600;
      viewport.content.width = (float)cw;
      viewport.content.height =
          0.0f; // height=0 so children start at y=0, not y=viewport_height
      global_layout_root->layout(viewport);
      master_display_list = build_display_list(global_layout_root);
      std::cerr << "Display list: " << master_display_list.size()
                << " commands\n";

      // Kick off async image fetching
      g_current_page_url = url;
      if (g_hwnd && global_layout_root) {
        std::vector<std::string> img_urls;
        collect_img_urls(global_layout_root, g_current_page_url, img_urls);
        if (!img_urls.empty()) {
          ImgFetchParams *p = new ImgFetchParams();
          p->urls = img_urls;
          p->hwnd = g_hwnd;
          HANDLE ht = CreateThread(NULL, 0, fetch_images_thread, p, 0, NULL);
          if (ht)
            CloseHandle(ht); // detach
        }
      }
    } else {
      master_display_list.clear();
    }

    // Reset scroll
    scroll_y = 0;

    // Update UI state
    browser_ui.set_loading(false);
    if (url.empty()) {
      browser_ui.set_status("Ready");
    } else {
      browser_ui.set_status(url);
    }

    // Update the tab title from <title> if present
    std::string page_title;
    if (root) {
      auto title_node = root->query_selector("title");
      if (title_node) {
        for (auto &child : title_node->children) {
          if (child->type == NodeType::Text) {
            page_title = child->data;
            break;
          }
        }
      }
    }
    Tab *tab = browser_ui.active_tab();
    if (tab && !page_title.empty()) {
      tab->title = page_title;
    } else if (tab && !url.empty()) {
      tab->title = url;
    }

  } catch (const std::exception &e) {
    std::cerr << "load_page error: " << e.what() << "\n";
    browser_ui.set_loading(false);
    browser_ui.set_status("Error loading page");
    master_display_list.clear();
    global_layout_root = nullptr;
  } catch (...) {
    std::cerr << "load_page error: unknown exception\n";
    browser_ui.set_loading(false);
    browser_ui.set_status("Error loading page");
    master_display_list.clear();
    global_layout_root = nullptr;
  }
}

// Helper to fill rectangular areas on our buffer
void FillRect(int start_x, int start_y, int width, int height, uint32_t color) {
  if (!buffer_memory)
    return;
  uint32_t *pixel = (uint32_t *)buffer_memory;
  for (int y = start_y; y < start_y + height && y < buffer_height; ++y) {
    if (y < 0)
      continue;
    for (int x = start_x; x < start_x + width && x < buffer_width; ++x) {
      if (x < 0)
        continue;
      pixel[y * buffer_width + x] = color;
    }
  }
}

// ============================================================================
//  Window Procedure — Win32 Event Loop
// ============================================================================

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam,
                            LPARAM lParam) {
  switch (uMsg) {
  case WM_CLOSE:
    running = false;
    break;

  case WM_DESTROY:
    PostQuitMessage(0);
    running = false;
    break;

  case WM_MOUSEMOVE: {
    if (!app_initialized)
      break;
    int mx = (short)LOWORD(lParam);
    int my = (short)HIWORD(lParam);
    if (is_scrolling) {
      int dy = my - scroll_drag_start_y;
      int content_h = browser_ui.content_height();
      float total_h = global_layout_root
                          ? global_layout_root->dimensions.content.height
                          : (float)content_h;
      if (total_h > content_h) {
        float thumb_h =
            (std::max)(20.0f, (float)content_h * (float)content_h / total_h);
        float ratio =
            (total_h - (float)content_h) / (float)(content_h - thumb_h);
        scroll_y = scroll_start_val + (int)(dy * ratio);
        if (scroll_y < 0)
          scroll_y = 0;
        if (scroll_y > total_h - content_h)
          scroll_y = (int)(total_h - content_h);
        InvalidateRect(hwnd, NULL, FALSE);
      }
    }
    browser_ui.on_mouse_move(mx, my);

    // Hover detection for :hover CSS
    if (global_layout_root && !is_scrolling) {
      int hx = mx;
      int hy = my - browser_ui.content_y() + scroll_y;
      std::function<std::shared_ptr<LayoutBox>(std::shared_ptr<LayoutBox>,int,int)> htest;
      htest=[&](std::shared_ptr<LayoutBox> b,int rx,int ry)->std::shared_ptr<LayoutBox>{
        if(!b)return nullptr;
        auto mb=b->dimensions.margin_box();
        if(rx<mb.x||rx>mb.x+mb.width||ry<mb.y||ry>mb.y+mb.height)return nullptr;
        for(auto&c:b->children){auto h=htest(c,rx,ry);if(h)return h;}
        return b;
      };
      auto hov=htest(global_layout_root,hx,hy);
      Node* nh=(hov&&hov->style_node)?hov->style_node->node.get():nullptr;
      if(nh!=g_hovered_node){
        static Node* last_hov=nullptr;
        if(last_hov)last_hov->attributes.erase("__hover");
        g_hovered_node=nh; last_hov=nh;
        if(nh)nh->attributes["__hover"]="1";
        if(g_dom_root){
          auto hs=build_style_tree(g_dom_root,g_main_stylesheet,
            g_hover_stylesheet.rules.empty()?nullptr:&g_hover_stylesheet,
            g_focus_stylesheet.rules.empty()?nullptr:&g_focus_stylesheet);
          auto lr=build_layout_tree(hs);
          if(lr){Dimensions vp;vp.content.width=(float)buffer_width;lr->layout(vp);
            master_display_list=build_display_list(lr);}
        }
        InvalidateRect(hwnd,NULL,FALSE);
      }
    }

    TRACKMOUSEEVENT tme = {};
    tme.cbSize = sizeof(tme);
    tme.dwFlags = TME_LEAVE;
    tme.hwndTrack = hwnd;
    TrackMouseEvent(&tme);
  } break;

  case WM_MOUSELEAVE:
    if (!app_initialized)
      break;
    browser_ui.on_mouse_move(-1, -1);
    break;

  case WM_LBUTTONDOWN: {
    if (!app_initialized)
      break;
    int mx = (short)LOWORD(lParam);
    int my = (short)HIWORD(lParam);

    UIHitResult hr = browser_ui.hit_test(mx, my);
    if (hr == UIHitResult::ContentArea) {
      int content_x = mx;
      int content_y = my - browser_ui.content_y() + scroll_y;

      std::function<std::shared_ptr<LayoutBox>(std::shared_ptr<LayoutBox>, int,
                                               int)>
          hit_test_content;
      hit_test_content = [&](std::shared_ptr<LayoutBox> box, int rx,
                             int ry) -> std::shared_ptr<LayoutBox> {
        if (!box)
          return nullptr;
        std::shared_ptr<LayoutBox> hit = nullptr;
        if (rx >= box->dimensions.content.x &&
            rx <= box->dimensions.content.x + box->dimensions.content.width &&
            ry >= box->dimensions.content.y &&
            ry <= box->dimensions.content.y + box->dimensions.content.height) {
          hit = box;
        }
        for (auto &c : box->children) {
          auto h = hit_test_content(c, rx, ry);
          if (h)
            hit = h;
        }
        return hit;
      };

      focused_box = hit_test_content(global_layout_root, content_x, content_y);

      // --- Handle JavaScript onclick ---
      if (focused_box && focused_box->style_node &&
          focused_box->style_node->node) {
        auto node = focused_box->style_node->node;
        if (node->attributes.count("onclick")) {
          std::string code = node->attributes["onclick"];
          std::cerr << "[Event] Triggering onclick for <" << node->data
                    << ">\n";

          // Find the current environment (we'll use a hack for now, or look it
          // up) In a real browser, this would be tied to the document/window
          // For now, let's assume we can get it or we re-run in a default env
          // (Improving this would require storing env in the document)
          // Use the persistent environment for events
          if (g_qjs_engine) {
            std::string err = qjs_eval(g_qjs_engine, code, "<onclick>");
            if (!err.empty())
              std::cerr << "[JS onclick error] " << err << "\n";
          }
          if (global_layout_root) {
            Dimensions viewport;
            viewport.content.width = (float)buffer_width;
            viewport.content.height = 0.0f;
            global_layout_root->layout(viewport);
            master_display_list = build_display_list(global_layout_root);
          }
          InvalidateRect(hwnd, NULL, FALSE);
        }
      }

      // Handle submit button clicks
      if (focused_box && focused_box->style_node &&
          focused_box->style_node->node) {
        std::string tag = focused_box->style_node->node->data;
        std::string type;
        if (focused_box->style_node->node->attributes.count("type")) {
          type = focused_box->style_node->node->attributes["type"];
        }
        if (tag == "button" || type == "submit" || type == "button") {
          std::function<std::string(std::shared_ptr<LayoutBox>)> find_input;
          find_input = [&](std::shared_ptr<LayoutBox> box) -> std::string {
            if (!box)
              return "";
            if (box->style_node && box->style_node->node &&
                box->style_node->node->data == "input") {
              std::string itype = box->style_node->node->attributes["type"];
              if (itype != "hidden" && itype != "submit" && itype != "button") {
                return box->style_node->node->attributes["value"];
              }
            }
            for (auto &c : box->children) {
              std::string res = find_input(c);
              if (!res.empty())
                return res;
            }
            return "";
          };

          std::string val = find_input(global_layout_root);
          std::string nav_url = "https://google.com/search?q=" + val;
          for (char &c : nav_url)
            if (c == ' ')
              c = '+';

          Tab *tab = browser_ui.active_tab();
          if (tab) {
            tab->push_url(nav_url);
            browser_ui.set_address_text(nav_url);
          }
          load_page(nav_url);
          focused_box = nullptr;
          InvalidateRect(hwnd, NULL, FALSE);
        }
      }
    } else {
      // Check for scrollbar hit
      if (mx >= buffer_width - SCROLLBAR_WIDTH && mx <= buffer_width) {
        is_scrolling = true;
        scroll_drag_start_y = my;
        scroll_start_val = scroll_y;
      } else {
        browser_ui.on_mouse_down(mx, my);
      }
    }
    InvalidateRect(hwnd, NULL, FALSE);
  } break;

  case WM_LBUTTONUP: {
    if (!app_initialized)
      break;
    int mx = (short)LOWORD(lParam);
    int my = (short)HIWORD(lParam);
    is_scrolling = false;
    browser_ui.on_mouse_up(mx, my);
  } break;

  case WM_MOUSEWHEEL: {
    if (!app_initialized)
      break;
    int delta = GET_WHEEL_DELTA_WPARAM(wParam);
    scroll_y -= (delta / 120) * SCROLL_STEP;

    int content_h = browser_ui.content_height();
    float total_h = global_layout_root
                        ? global_layout_root->dimensions.content.height
                        : (float)content_h;

    if (scroll_y < 0)
      scroll_y = 0;
    if (scroll_y > total_h - content_h)
      scroll_y = (int)std::max(0.0f, total_h - content_h);

    InvalidateRect(hwnd, NULL, FALSE);
  } break;

  case WM_KEYDOWN: {
    if (!app_initialized)
      break;
    browser_ui.on_key_down((int)wParam);

    // Tab keyboard shortcuts
    if (GetKeyState(VK_CONTROL) & 0x8000) {
      if (wParam == 'T') {
        browser_ui.add_tab("", "New Tab");
        browser_ui.focus_address_bar();
        load_page("");
        InvalidateRect(hwnd, NULL, FALSE);
      } else if (wParam == 'W') {
        browser_ui.close_tab(browser_ui.active_tab_index());
        Tab *t = browser_ui.active_tab();
        if (t)
          load_page(t->url);
        InvalidateRect(hwnd, NULL, FALSE);
      } else if (wParam == 'L') {
        browser_ui.focus_address_bar();
        InvalidateRect(hwnd, NULL, FALSE);
      } else if (wParam == 'R') {
        Tab *t = browser_ui.active_tab();
        if (t && !t->url.empty()) {
          load_page(t->url);
          InvalidateRect(hwnd, NULL, FALSE);
        }
      }
    }

    if (wParam == VK_F5) {
      Tab *t = browser_ui.active_tab();
      if (t && !t->url.empty()) {
        load_page(t->url);
        InvalidateRect(hwnd, NULL, FALSE);
      }
    }

    if (GetKeyState(VK_MENU) & 0x8000) {
      if (wParam == VK_LEFT) {
        Tab *t = browser_ui.active_tab();
        if (t && t->can_go_back()) {
          std::string url = t->go_back();
          browser_ui.set_address_text(url);
          load_page(url);
          InvalidateRect(hwnd, NULL, FALSE);
        }
      } else if (wParam == VK_RIGHT) {
        Tab *t = browser_ui.active_tab();
        if (t && t->can_go_forward()) {
          std::string url = t->go_forward();
          browser_ui.set_address_text(url);
          load_page(url);
          InvalidateRect(hwnd, NULL, FALSE);
        }
      }
    }
  } break;

  case WM_CHAR: {
    if (!app_initialized)
      break;
    char typed = (char)wParam;

    if (browser_ui.is_address_focused()) {
      browser_ui.on_char(typed);
      break;
    }

    if (focused_box && focused_box->style_node &&
        focused_box->style_node->node &&
        focused_box->style_node->node->data == "input") {
      auto &val = focused_box->style_node->node->attributes["value"];
      if (typed == '\b') {
        if (!val.empty())
          val.pop_back();
      } else if (typed >= 32 && typed <= 126) {
        val += typed;
      } else if (typed == '\r') {
        std::string nav_url = "https://google.com/search?q=" + val;
        for (char &c : nav_url)
          if (c == ' ')
            c = '+';
        Tab *tab = browser_ui.active_tab();
        if (tab) {
          tab->push_url(nav_url);
          browser_ui.set_address_text(nav_url);
        }
        load_page(nav_url);
      }
      if (global_layout_root) {
        master_display_list = build_display_list(global_layout_root);
        InvalidateRect(hwnd, NULL, FALSE);
      }
    }
  } break;

  case WM_SIZE: {
    if (!app_initialized)
      break;

    RECT rect;
    GetClientRect(hwnd, &rect);
    int win_w = rect.right - rect.left;
    int win_h = rect.bottom - rect.top;

    if (win_w < 1 || win_h < 1)
      break; // Minimized or too small

    browser_ui.resize(win_w, win_h);

    buffer_width = browser_ui.content_width();
    buffer_height = browser_ui.content_height();
    if (buffer_width < 1)
      buffer_width = 1;
    if (buffer_height < 1)
      buffer_height = 1;
    g_viewport_height = buffer_height;
    g_viewport_width = buffer_width;

    if (buffer_memory) {
      VirtualFree(buffer_memory, 0, MEM_RELEASE);
      buffer_memory = nullptr;
    }

    bitmap_info.bmiHeader.biSize = sizeof(bitmap_info.bmiHeader);
    bitmap_info.bmiHeader.biWidth = buffer_width;
    bitmap_info.bmiHeader.biHeight = -buffer_height; // Top-down
    bitmap_info.bmiHeader.biPlanes = 1;
    bitmap_info.bmiHeader.biBitCount = 32;
    bitmap_info.bmiHeader.biCompression = BI_RGB;

    int buffer_size = buffer_width * buffer_height * 4;
    if (buffer_size > 0) {
      buffer_memory = VirtualAlloc(0, buffer_size, MEM_COMMIT, PAGE_READWRITE);
    }

    // Re-layout on resize
    if (global_layout_root) {
      Dimensions viewport;
      viewport.content.width = (float)buffer_width;
      viewport.content.height = 0.0f; // height=0 so children start at y=0
      global_layout_root->layout(viewport);
      master_display_list = build_display_list(global_layout_root);
    }
    InvalidateRect(hwnd, NULL, FALSE);
  } break;

  case WM_PAINT: {
    PAINTSTRUCT ps;
    HDC window_dc = BeginPaint(hwnd, &ps);

    RECT client;
    GetClientRect(hwnd, &client);
    int win_w = client.right - client.left;
    int win_h = client.bottom - client.top;

    if (win_w < 1 || win_h < 1) {
      EndPaint(hwnd, &ps);
      break;
    }

    HDC mem_dc = CreateCompatibleDC(window_dc);
    if (!mem_dc) {
      EndPaint(hwnd, &ps);
      break;
    }

    HBITMAP mem_bmp = CreateCompatibleBitmap(window_dc, win_w, win_h);
    if (!mem_bmp) {
      DeleteDC(mem_dc);
      EndPaint(hwnd, &ps);
      break;
    }
    HGDIOBJ old_bmp = SelectObject(mem_dc, mem_bmp);

    // Fill entire window with a dark background as fallback
    RECT fill_r = {0, 0, win_w, win_h};
    HBRUSH dark_br = CreateSolidBrush(RGB(34, 36, 42));
    ::FillRect(mem_dc, &fill_r, dark_br);
    DeleteObject(dark_br);

    // Paint chrome (tabs + toolbar + status bar)
    if (app_initialized) {
      browser_ui.paint(mem_dc);
    }

    // Paint web content into the content area
    if (app_initialized && buffer_memory && buffer_width > 0 &&
        buffer_height > 0) {
      // Always clear to white — the display list SolidColor commands paint the
      // actual backgrounds on top. Trying to guess the page bg from the display
      // list is unreliable because the first wide rect may be a navbar, not
      // body.
      uint32_t bg_color = 0x00FFFFFF;
      uint32_t *pixel = (uint32_t *)buffer_memory;
      int total_pixels = buffer_width * buffer_height;
      for (int i = 0; i < total_pixels; ++i) {
        *pixel++ = bg_color;
      }

      // Render display list — normal elements first, fixed elements on top
      // Pass 1: non-fixed SolidColor backgrounds
      for (const auto &cmd : master_display_list) {
        if (cmd.type == DisplayCommandType::SolidColor && !cmd.fixed) {
          int y = (int)cmd.rect.y - scroll_y;
          FillRect((int)cmd.rect.x, y, (int)cmd.rect.width,
                   (int)cmd.rect.height, cmd.color);
        }
      }
      // Pass 2: fixed SolidColor backgrounds (on top)
      for (const auto &cmd : master_display_list) {
        if (cmd.type == DisplayCommandType::SolidColor && cmd.fixed) {
          FillRect((int)cmd.rect.x, (int)cmd.rect.y, (int)cmd.rect.width,
                   (int)cmd.rect.height, cmd.color);
        }
      }

      // Blit pixel buffer to the content region
      HDC content_dc = CreateCompatibleDC(mem_dc);
      if (content_dc) {
        HBITMAP content_bmp =
            CreateCompatibleBitmap(mem_dc, buffer_width, buffer_height);
        if (content_bmp) {
          HGDIOBJ old_content_bmp = SelectObject(content_dc, content_bmp);

          StretchDIBits(content_dc, 0, 0, buffer_width, buffer_height, 0, 0,
                        buffer_width, buffer_height, buffer_memory,
                        &bitmap_info, DIB_RGB_COLORS, SRCCOPY);

          // Helper: draw a single text display command
          auto draw_text_cmd = [&](const DisplayCommand &cmd) {
            COLORREF gdi_color = RGB((cmd.color >> 16) & 0xFF,
                                     (cmd.color >> 8) & 0xFF, cmd.color & 0xFF);
            SetTextColor(content_dc, gdi_color);
            HFONT hFont = CreateFontA(
                cmd.font_size, 0, 0, 0, cmd.bold ? FW_BOLD : FW_NORMAL, FALSE,
                FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
                CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH,
                "Arial");
            if (hFont) {
              HGDIOBJ old_font = SelectObject(content_dc, hFont);
              int wlen = MultiByteToWideChar(CP_UTF8, 0, cmd.text.c_str(),
                                             (int)cmd.text.length(), NULL, 0);
              if (wlen > 0) {
                std::wstring wstr(wlen, 0);
                MultiByteToWideChar(CP_UTF8, 0, cmd.text.c_str(),
                                    (int)cmd.text.length(), &wstr[0], wlen);
                int y =
                    cmd.fixed ? (int)cmd.rect.y : (int)cmd.rect.y - scroll_y;
                TextOutW(content_dc, (int)cmd.rect.x, y, wstr.c_str(), wlen);
              }
              SelectObject(content_dc, old_font);
              DeleteObject(hFont);
            }
          };

          // Helper: blit one img box
          auto blit_one_img = [&](const std::shared_ptr<LayoutBox> &box,
                                  bool want_fixed) {
            if (!box || !box->style_node || !box->style_node->node)
              return;
            bool is_fixed_box = box->style_node->value("position") == "fixed";
            if (is_fixed_box != want_fixed)
              return;
            if (box->style_node->node->type != NodeType::Element ||
                box->style_node->node->data != "img")
              return;
            auto it_src = box->style_node->node->attributes.find("src");
            if (it_src == box->style_node->node->attributes.end())
              return;
            std::string url = resolve_url(it_src->second, g_current_page_url);
            auto it_img = g_image_cache.find(url);
            if (it_img == g_image_cache.end() || it_img->second.width <= 0)
              return;
            const CachedImage &img = it_img->second;
            int dest_x = (int)box->dimensions.content.x;
            int dest_y = is_fixed_box
                             ? (int)box->dimensions.content.y
                             : (int)box->dimensions.content.y - scroll_y;
            int dest_w = (int)box->dimensions.content.width;
            int dest_h = (int)box->dimensions.content.height;
            if (dest_w <= 0)
              dest_w = img.width;
            if (dest_h <= 0)
              dest_h = img.height;
            BITMAPINFO img_bmi = {};
            img_bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
            img_bmi.bmiHeader.biWidth = img.width;
            img_bmi.bmiHeader.biHeight = -img.height;
            img_bmi.bmiHeader.biPlanes = 1;
            img_bmi.bmiHeader.biBitCount = 32;
            img_bmi.bmiHeader.biCompression = BI_RGB;
            StretchDIBits(content_dc, dest_x, dest_y, dest_w, dest_h, 0, 0,
                          img.width, img.height, img.pixels.data(), &img_bmi,
                          DIB_RGB_COLORS, SRCCOPY);
          };

          // Recursive image walker
          std::function<void(const std::shared_ptr<LayoutBox> &, bool)>
              blit_images_pass;
          blit_images_pass = [&](const std::shared_ptr<LayoutBox> &box,
                                 bool want_fixed) {
            if (!box)
              return;
            blit_one_img(box, want_fixed);
            for (auto &child : box->children)
              blit_images_pass(child, want_fixed);
          };

          SetBkMode(content_dc, TRANSPARENT);

          // Pass 1: non-fixed text
          for (const auto &cmd : master_display_list)
            if (cmd.type == DisplayCommandType::Text && !cmd.fixed)
              draw_text_cmd(cmd);

          // Pass 2: non-fixed images
          if (global_layout_root) {
            EnterCriticalSection(&g_image_cache_cs);
            blit_images_pass(global_layout_root, false);
            LeaveCriticalSection(&g_image_cache_cs);
          }

          // Pass 3: fixed text (on top of page content)
          for (const auto &cmd : master_display_list)
            if (cmd.type == DisplayCommandType::Text && cmd.fixed)
              draw_text_cmd(cmd);

          // Pass 4: fixed images (topmost layer)
          if (global_layout_root) {
            EnterCriticalSection(&g_image_cache_cs);
            blit_images_pass(global_layout_root, true);
            LeaveCriticalSection(&g_image_cache_cs);
          }

          int content_y = browser_ui.content_y();
          BitBlt(mem_dc, 0, content_y, buffer_width, buffer_height, content_dc,
                 0, 0, SRCCOPY);

          SelectObject(content_dc, old_content_bmp);
          DeleteObject(content_bmp);
        }
        DeleteDC(content_dc);
      }

      // Draw Scrollbar
      int content_h = browser_ui.content_height();
      float total_h = global_layout_root
                          ? global_layout_root->dimensions.content.height
                          : (float)content_h;
      if (total_h > content_h) {
        int cy = browser_ui.content_y();
        float thumb_h =
            (std::max)(20.0f, (float)content_h * (float)content_h / total_h);
        float thumb_y = (float)scroll_y * (float)(content_h - thumb_h) /
                        (total_h - (float)content_h);

        // Track
        RECT track_r = {buffer_width - SCROLLBAR_WIDTH, cy, buffer_width,
                        cy + content_h};
        HBRUSH track_br = CreateSolidBrush(RGB(45, 47, 54));
        ::FillRect(mem_dc, &track_r, track_br);
        DeleteObject(track_br);

        // Thumb
        RECT thumb_r = {buffer_width - SCROLLBAR_WIDTH + 2, cy + (int)thumb_y,
                        buffer_width - 2, cy + (int)thumb_y + (int)thumb_h};
        HBRUSH thumb_br = CreateSolidBrush(is_scrolling ? RGB(100, 105, 120)
                                                        : RGB(75, 78, 88));
        ::FillRect(mem_dc, &thumb_r, thumb_br);
        DeleteObject(thumb_br);
      }
    }

    // Final blit to window
    BitBlt(window_dc, 0, 0, win_w, win_h, mem_dc, 0, 0, SRCCOPY);

    SelectObject(mem_dc, old_bmp);
    DeleteObject(mem_bmp);
    DeleteDC(mem_dc);

    EndPaint(hwnd, &ps);
  } break;

  case WM_USER + 1:
    // Image fetch thread finished a batch — invalidate to repaint
    InvalidateRect(hwnd, NULL, FALSE);
    break;
  }
  return DefWindowProcA(hwnd, uMsg, wParam, lParam);
}

// ============================================================================
//  Entry Point
// ============================================================================

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/,
                   LPSTR pCmdLine, int nCmdShow) {
  AllocConsole();
  freopen("out.txt", "w", stdout);
  freopen("out.txt", "w", stderr);

  std::cout << "--- Scratch Browser Engine v47 initializing ---\n";

  // ── Register Window Class ──
  const char CLASS_NAME[] = "ScratchBrowserWindowClass";

  WNDCLASS wc = {};
  wc.lpfnWndProc = WindowProc;
  wc.hInstance = hInstance;
  wc.lpszClassName = CLASS_NAME;
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.style = CS_OWNDC;

  RegisterClassA(&wc);

  int initial_w = 1024;
  int initial_h = 720;

  HWND hwnd = CreateWindowExA(
      0, CLASS_NAME, "Scratch Browser", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT,
      CW_USEDEFAULT, initial_w, initial_h, NULL, NULL, hInstance, NULL);

  if (hwnd == NULL) {
    std::cerr << "Failed to create window!\n";
    return 1;
  }

  // ── Initialize GDI+ for image decoding ──
  InitializeCriticalSection(&g_image_cache_cs);
  Gdiplus::GdiplusStartupInput gdip_input;
  Gdiplus::GdiplusStartup(&g_gdip_token, &gdip_input, NULL);
  g_hwnd = hwnd;

  // ── Initialize the UI backend ──
  RECT rect;
  GetClientRect(hwnd, &rect);
  int win_w = rect.right - rect.left;
  int win_h = rect.bottom - rect.top;

  g_viewport_height = win_h;
  g_viewport_width = win_w;

  browser_ui.init(hwnd, win_w, win_h);

  // ── Set up navigation callback ──
  // Use explicit capture to avoid dangling reference issues
  HWND nav_hwnd = hwnd; // Copy for the lambda
  browser_ui.set_navigate_callback([nav_hwnd](const std::string &url) {
    load_page(url);
    InvalidateRect(nav_hwnd, NULL, FALSE);
  });

  // ── Allocate initial buffer ──
  buffer_width = browser_ui.content_width();
  buffer_height = browser_ui.content_height();
  if (buffer_width < 1)
    buffer_width = 800;
  if (buffer_height < 1)
    buffer_height = 600;

  bitmap_info.bmiHeader.biSize = sizeof(bitmap_info.bmiHeader);
  bitmap_info.bmiHeader.biWidth = buffer_width;
  bitmap_info.bmiHeader.biHeight = -buffer_height;
  bitmap_info.bmiHeader.biPlanes = 1;
  bitmap_info.bmiHeader.biBitCount = 32;
  bitmap_info.bmiHeader.biCompression = BI_RGB;

  int buffer_size = buffer_width * buffer_height * 4;
  if (buffer_size > 0) {
    buffer_memory = VirtualAlloc(0, buffer_size, MEM_COMMIT, PAGE_READWRITE);
  }

  // Mark app as fully initialized BEFORE loading the first page
  app_initialized = true;

  // ── Handle command-line URL ──
  std::string cmdLine(pCmdLine);
  if (!cmdLine.empty()) {
    Tab *tab = browser_ui.active_tab();
    if (tab) {
      tab->push_url(cmdLine);
    }
    browser_ui.set_address_text(cmdLine);
    load_page(cmdLine);
  } else {
    load_page(""); // Load home page
  }

  std::cout << "--- Initialization complete, showing window ---\n";

  ShowWindow(hwnd, nCmdShow);

  // Force initial WM_SIZE to sync layout
  SendMessageA(hwnd, WM_SIZE, 0,
               MAKELPARAM(rect.right - rect.left, rect.bottom - rect.top));

  // ── Message Loop ──
  MSG msg = {};
  while (GetMessageA(&msg, NULL, 0, 0) > 0) {
    TranslateMessage(&msg);
    DispatchMessageA(&msg);
  }

  // Cleanup
  if (buffer_memory) {
    VirtualFree(buffer_memory, 0, MEM_RELEASE);
    buffer_memory = nullptr;
  }
  if (g_gdip_token)
    Gdiplus::GdiplusShutdown(g_gdip_token);
  DeleteCriticalSection(&g_image_cache_cs);

  return 0;
}
